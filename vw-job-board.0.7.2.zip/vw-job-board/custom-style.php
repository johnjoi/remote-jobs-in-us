<?php

	$vw_job_board_custom_css= "";

	/*----------------------First highlight color-------------------*/

	$vw_job_board_first_color = get_theme_mod('vw_job_board_first_color');

	if($vw_job_board_first_color != false){
		$vw_job_board_custom_css .='.topbar, #preloader, #footer-2, .pagination a:hover, .pagination .current:hover{';
			$vw_job_board_custom_css .='background-color: '.esc_attr($vw_job_board_first_color).';';
		$vw_job_board_custom_css .='}';
	}

	if($vw_job_board_first_color != false){
		$vw_job_board_custom_css .='.main-navigation a:hover, .main-navigation ul ul a:hover, #slider .inner_carousel h1 a:hover, #featured-job-section h3 a:hover, .post-main-box:hover h2 a, .post-main-box:hover .post-info span a, .single-post .post-info:hover a, .middle-bar h6, .post-main-box:hover h3 a,#sidebar ul li a:hover, #footer li a:hover,.post-navigation a:hover .post-title, .post-navigation a:focus .post-title,.post-navigation a:hover,.post-navigation a:focus{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_first_color).';';
		$vw_job_board_custom_css .='}';
	}

	/*----------------------Second highlight color-------------------*/

	$vw_job_board_second_color = get_theme_mod('vw_job_board_second_color');

	if($vw_job_board_first_color != false || $vw_job_board_second_color != false){
		$vw_job_board_custom_css .='.main-header .header-btn a, #featured-job-section .featured-cat-btn a, .slide-search input[type="submit"], .view-all-btn a,.more-btn a,#comments input[type="submit"],#comments a.comment-reply-link,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button,.woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,nav.woocommerce-MyAccount-navigation ul li,.pro-button a, .woocommerce a.added_to_cart.wc-forward, #footer .wp-block-search .wp-block-search__button, #sidebar .wp-block-search .wp-block-search__button, .scrollup i, #sidebar h3, #sidebar .tagcloud a:hover, .woocommerce span.onsale,.bradcrumbs a:hover, .bradcrumbs span, .post-categories li a:hover, #sidebar label.wp-block-search__label, #sidebar .wp-block-heading,.wp-block-tag-cloud a:hover,#sidebar a.custom_facebook, #sidebar a.custom_twitter, #sidebar a.custom_linkedin, #sidebar a.custom_pinterest, #sidebar a.custom_tumblr, #sidebar a.custom_instagram, #sidebar a.custom_youtube,.wp-block-button__link,.bradcrumbs a, .post-categories li a,.wc-block-components-order-summary-item__quantity,.wp-block-woocommerce-cart .wc-block-cart__submit-button, .wc-block-components-checkout-place-order-button, .wc-block-components-totals-coupon__button{
		background: transparent linear-gradient(126deg, '.esc_attr($vw_job_board_second_color).' 0%, '.esc_attr($vw_job_board_first_color).' 100%) 0% 0% no-repeat !important;
		}';
	}

	$vw_job_board_custom_css .='@media screen and (max-width:1000px) {';
		if($vw_job_board_first_color != false){
			$vw_job_board_custom_css .='.main-navigation a:hover{
				color:'.esc_attr($vw_job_board_first_color).' !important;
			}';
		}

		if($vw_job_board_first_color != false || $vw_job_board_second_color != false){
			$vw_job_board_custom_css .='.toggle-nav i{
				background: transparent linear-gradient(126deg, '.esc_attr($vw_job_board_second_color).' 0%, '.esc_attr($vw_job_board_first_color).' 100%) 0% 0% no-repeat;
			}';
		}
	$vw_job_board_custom_css .='}';

	/*---------------------------Width Layout -------------------*/

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_width_option','Wide Width');
    if($vw_job_board_theme_lay == 'Boxed'){
		$vw_job_board_custom_css .='body{';
			$vw_job_board_custom_css .='max-width: 1140px; width: 100%; padding-right: 15px; padding-left: 15px; margin-right: auto; margin-left: auto;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='.scrollup i{';
			$vw_job_board_custom_css .='right: 100px;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_theme_lay == 'Wide Width'){
		$vw_job_board_custom_css .='body{';
			$vw_job_board_custom_css .='width: 100%;padding-right: 15px;padding-left: 15px;margin-right: auto;margin-left: auto;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_theme_lay == 'Full Width'){
		$vw_job_board_custom_css .='body{';
			$vw_job_board_custom_css .='max-width: 100%;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='.topbar{';
			$vw_job_board_custom_css .='border-bottom-left-radius: 0px; border-bottom-right-radius: 0px;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#slider, #slider img, #footer, #footer-2{';
			$vw_job_board_custom_css .='border-radius: 0px;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='.main-header{';
			$vw_job_board_custom_css .='padding: 0px 20px 0px 20px;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#featured-job-section{';
			$vw_job_board_custom_css .='padding: 30px;';
		$vw_job_board_custom_css .='}';
	}

	/*------------------Slider Content Layout -------------------*/

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_slider_content_option','Left');
    if($vw_job_board_theme_lay == 'Left'){
		$vw_job_board_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$vw_job_board_custom_css .='text-align:left; left:15%; right:45%;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_theme_lay == 'Center'){
		$vw_job_board_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$vw_job_board_custom_css .='text-align:center; left:20%; right:20%;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_theme_lay == 'Right'){
		$vw_job_board_custom_css .='#slider .carousel-caption, #slider .inner_carousel, #slider .inner_carousel h1{';
			$vw_job_board_custom_css .='text-align:right; left:45%; right:15%;';
		$vw_job_board_custom_css .='}';
	}

	/*--------------------------- Slider Opacity -------------------*/

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_slider_opacity_color','0.8');
	if($vw_job_board_theme_lay == '0'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.1'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.1';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.2'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.2';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.3'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.3';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.4'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.4';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.5'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.5';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.6'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.6';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.7'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.7';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.8'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.8';
		$vw_job_board_custom_css .='}';
		}else if($vw_job_board_theme_lay == '0.9'){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:0.9';
		$vw_job_board_custom_css .='}';
		}

	/*---------------------- Slider Image Overlay ------------------------*/

	$vw_job_board_slider_image_overlay = get_theme_mod('vw_job_board_slider_image_overlay', true);
	if($vw_job_board_slider_image_overlay == false){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='opacity:1;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_slider_image_overlay_color = get_theme_mod('vw_job_board_slider_image_overlay_color', true);
	if($vw_job_board_slider_image_overlay_color != false){
		$vw_job_board_custom_css .='#slider{';
			$vw_job_board_custom_css .='background-color: '.esc_attr($vw_job_board_slider_image_overlay_color).';';
		$vw_job_board_custom_css .='}';
	}

	/*----------------Responsive Media -----------------------*/

	$vw_job_board_resp_slider = get_theme_mod( 'vw_job_board_resp_slider_hide_show',false);
	if($vw_job_board_resp_slider == true && get_theme_mod( 'vw_job_board_slider_hide_show', true) == false){
    	$vw_job_board_custom_css .='#slider{';
			$vw_job_board_custom_css .='display:none;';
		$vw_job_board_custom_css .='} ';
	}
    if($vw_job_board_resp_slider == true){
    	$vw_job_board_custom_css .='@media screen and (max-width:575px) {';
		$vw_job_board_custom_css .='#slider{';
			$vw_job_board_custom_css .='display:block;';
		$vw_job_board_custom_css .='} }';
	}else if($vw_job_board_resp_slider == false){
		$vw_job_board_custom_css .='@media screen and (max-width:575px) {';
		$vw_job_board_custom_css .='#slider{';
			$vw_job_board_custom_css .='display:none;';
		$vw_job_board_custom_css .='} }';
		$vw_job_board_custom_css .='@media screen and (max-width:575px){';
		$vw_job_board_custom_css .='.page-template-custom-home-page.admin-bar .homepageheader{';
			$vw_job_board_custom_css .='margin-top: 45px;';
		$vw_job_board_custom_css .='} }';
	}

	$vw_job_board_resp_sidebar = get_theme_mod( 'vw_job_board_sidebar_hide_show',true);
    if($vw_job_board_resp_sidebar == true){
    	$vw_job_board_custom_css .='@media screen and (max-width:575px) {';
		$vw_job_board_custom_css .='#sidebar{';
			$vw_job_board_custom_css .='display:block;';
		$vw_job_board_custom_css .='} }';
	}else if($vw_job_board_resp_sidebar == false){
		$vw_job_board_custom_css .='@media screen and (max-width:575px) {';
		$vw_job_board_custom_css .='#sidebar{';
			$vw_job_board_custom_css .='display:none;';
		$vw_job_board_custom_css .='} }';
	}

	$vw_job_board_resp_scroll_top = get_theme_mod( 'vw_job_board_resp_scroll_top_hide_show',true);
	if($vw_job_board_resp_scroll_top == true && get_theme_mod( 'vw_job_board_hide_show_scroll',true) == false){
    	$vw_job_board_custom_css .='.scrollup i{';
			$vw_job_board_custom_css .='visibility:hidden !important;';
		$vw_job_board_custom_css .='} ';
	}
    if($vw_job_board_resp_scroll_top == true){
    	$vw_job_board_custom_css .='@media screen and (max-width:575px) {';
		$vw_job_board_custom_css .='.scrollup i{';
			$vw_job_board_custom_css .='visibility:visible !important;';
		$vw_job_board_custom_css .='} }';
	}else if($vw_job_board_resp_scroll_top == false){
		$vw_job_board_custom_css .='@media screen and (max-width:575px){';
		$vw_job_board_custom_css .='.scrollup i{';
			$vw_job_board_custom_css .='visibility:hidden !important;';
		$vw_job_board_custom_css .='} }';
	}

	$vw_job_board_resp_menu_toggle_btn_bg_color = get_theme_mod('vw_job_board_resp_menu_toggle_btn_bg_color');
	if($vw_job_board_resp_menu_toggle_btn_bg_color != false){
		$vw_job_board_custom_css .='.toggle-nav i,.sidenav .closebtn, .left-menu .closebtn{';
			$vw_job_board_custom_css .='background: '.esc_attr($vw_job_board_resp_menu_toggle_btn_bg_color).';';
		$vw_job_board_custom_css .='}';
	}
	
	/*---------------- Button Settings ------------------*/

	$vw_job_board_button_border_radius = get_theme_mod('vw_job_board_button_border_radius');
	if($vw_job_board_button_border_radius != false){
		$vw_job_board_custom_css .='.post-main-box .more-btn a{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_button_border_radius).'px;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_button_padding_top_bottom = get_theme_mod('vw_job_board_button_padding_top_bottom');
	$vw_job_board_button_padding_left_right = get_theme_mod('vw_job_board_button_padding_left_right');
	if($vw_job_board_button_padding_top_bottom != false || $vw_job_board_button_padding_left_right != false){
		$vw_job_board_custom_css .='.post-main-box .more-btn a{';
			$vw_job_board_custom_css .='padding-top: '.esc_attr($vw_job_board_button_padding_top_bottom).'!important; 
			padding-bottom: '.esc_attr($vw_job_board_button_padding_top_bottom).'!important;
			padding-left: '.esc_attr($vw_job_board_button_padding_left_right).'!important;
			padding-right: '.esc_attr($vw_job_board_button_padding_left_right).'!important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_button_font_size = get_theme_mod('vw_job_board_button_font_size',14);
	$vw_job_board_custom_css .='.post-main-box .more-btn a{';
		$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_button_font_size).';';
	$vw_job_board_custom_css .='}';

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_button_text_transform','Uppercase');
	if($vw_job_board_theme_lay == 'Capitalize'){
		$vw_job_board_custom_css .='.post-main-box .more-btn a{';
			$vw_job_board_custom_css .='text-transform:Capitalize;';
		$vw_job_board_custom_css .='}';
	}
	if($vw_job_board_theme_lay == 'Lowercase'){
		$vw_job_board_custom_css .='.post-main-box .more-btn a{';
			$vw_job_board_custom_css .='text-transform:Lowercase;';
		$vw_job_board_custom_css .='}';
	}
	if($vw_job_board_theme_lay == 'Uppercase'){ 
		$vw_job_board_custom_css .='.post-main-box .more-btn a{';
			$vw_job_board_custom_css .='text-transform:Uppercase;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_button_letter_spacing = get_theme_mod('vw_job_board_button_letter_spacing',14);
	$vw_job_board_custom_css .='.post-main-box .more-btn a{';
		$vw_job_board_custom_css .='letter-spacing: '.esc_attr($vw_job_board_button_letter_spacing).';';
	$vw_job_board_custom_css .='}';
	/*---------------------------Blog Layout -------------------*/

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_blog_layout_option','Default');
    if($vw_job_board_theme_lay == 'Default'){
		$vw_job_board_custom_css .='.post-main-box{';
			$vw_job_board_custom_css .='';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_theme_lay == 'Center'){
		$vw_job_board_custom_css .='.post-main-box, .post-main-box h2, .post-info, .new-text p, .content-bttn{';
			$vw_job_board_custom_css .='text-align:center;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='.post-info{';
			$vw_job_board_custom_css .='margin-top:10px;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='.post-info hr{';
			$vw_job_board_custom_css .='margin:15px auto;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_theme_lay == 'Left'){
		$vw_job_board_custom_css .='.post-main-box, .post-main-box h2, .post-info, .new-text p, .content-bttn, #our-services p{';
			$vw_job_board_custom_css .='text-align:Left;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='.post-info hr{';
			$vw_job_board_custom_css .='margin-bottom:10px;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='.post-main-box h2{';
			$vw_job_board_custom_css .='margin-top:10px;';
		$vw_job_board_custom_css .='}';
	}

	/*--------------------- Blog Page Posts -------------------*/

	$vw_job_board_blog_page_posts_settings = get_theme_mod( 'vw_job_board_blog_page_posts_settings','Into Blocks');
    if($vw_job_board_blog_page_posts_settings == 'Without Blocks'){
		$vw_job_board_custom_css .='.post-main-box{';
			$vw_job_board_custom_css .='box-shadow: none; border: none; margin:30px 0;background:none;';
		$vw_job_board_custom_css .='}';
	}

	// featured image dimention
	$vw_job_board_blog_post_featured_image_dimension = get_theme_mod('vw_job_board_blog_post_featured_image_dimension', 'default');
	$vw_job_board_blog_post_featured_image_custom_width = get_theme_mod('vw_job_board_blog_post_featured_image_custom_width',250);
	$vw_job_board_blog_post_featured_image_custom_height = get_theme_mod('vw_job_board_blog_post_featured_image_custom_height',250);
	if($vw_job_board_blog_post_featured_image_dimension == 'custom'){
		$vw_job_board_custom_css .='.post-main-box img{';
			$vw_job_board_custom_css .='width: '.esc_attr($vw_job_board_blog_post_featured_image_custom_width).'; height: '.esc_attr($vw_job_board_blog_post_featured_image_custom_height).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_featured_image_border_radius = get_theme_mod('vw_job_board_featured_image_border_radius', 0);
	if($vw_job_board_featured_image_border_radius != false){
		$vw_job_board_custom_css .='.box-image img, .feature-box img{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_featured_image_border_radius).'px;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_featured_image_box_shadow = get_theme_mod('vw_job_board_featured_image_box_shadow',0);
	if($vw_job_board_featured_image_box_shadow != false){
		$vw_job_board_custom_css .='.box-image img, #content-vw img{';
			$vw_job_board_custom_css .='box-shadow: '.esc_attr($vw_job_board_featured_image_box_shadow).'px '.esc_attr($vw_job_board_featured_image_box_shadow).'px '.esc_attr($vw_job_board_featured_image_box_shadow).'px #cccccc;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_singlepost_image_box_shadow = get_theme_mod('vw_job_board_singlepost_image_box_shadow',0);
	if($vw_job_board_singlepost_image_box_shadow != false){
		$web_designer_custom_css .='.feature-box img{';
			$web_designer_custom_css .='box-shadow: '.esc_attr($vw_job_board_singlepost_image_box_shadow).'px '.esc_attr($vw_job_board_singlepost_image_box_shadow).'px '.esc_attr($vw_job_board_singlepost_image_box_shadow).'px #cccccc;';
		$web_designer_custom_css .='}';
	}

	$vw_job_board_single_blog_post_navigation_show_hide = get_theme_mod('vw_job_board_single_blog_post_navigation_show_hide',true);
	if($vw_job_board_single_blog_post_navigation_show_hide != true){
		$vw_job_board_custom_css .='.post-navigation{';
			$vw_job_board_custom_css .='display: none;';
		$vw_job_board_custom_css .='}';
	}

	/*-------------- Copyright Alignment ----------------*/

	$vw_job_board_copyright_background_color = get_theme_mod('vw_job_board_copyright_background_color');
	if($vw_job_board_copyright_background_color != false){
		$vw_job_board_custom_css .='#footer-2{';
			$vw_job_board_custom_css .='background-color: '.esc_attr($vw_job_board_copyright_background_color).';';
		$vw_job_board_custom_css .='}';
	} 

	$vw_job_board_footer_widgets_heading = get_theme_mod( 'vw_job_board_footer_widgets_heading','Left');
    if($vw_job_board_footer_widgets_heading == 'Left'){
		$vw_job_board_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
		$vw_job_board_custom_css .='text-align: left;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_footer_widgets_heading == 'Center'){
		$vw_job_board_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$vw_job_board_custom_css .='text-align: center;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_footer_widgets_heading == 'Right'){
		$vw_job_board_custom_css .='#footer h3, #footer .wp-block-search .wp-block-search__label{';
			$vw_job_board_custom_css .='text-align: right;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_footer_widgets_content = get_theme_mod( 'vw_job_board_footer_widgets_content','Left');
    if($vw_job_board_footer_widgets_content == 'Left'){
		$vw_job_board_custom_css .='#footer .widget{';
		$vw_job_board_custom_css .='text-align: left;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_footer_widgets_content == 'Center'){
		$vw_job_board_custom_css .='#footer .widget{';
			$vw_job_board_custom_css .='text-align: center;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_footer_widgets_content == 'Right'){
		$vw_job_board_custom_css .='#footer .widget{';
			$vw_job_board_custom_css .='text-align: right;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_copyright_alingment = get_theme_mod('vw_job_board_copyright_alingment');
	if($vw_job_board_copyright_alingment != false){
		$vw_job_board_custom_css .='.copyright p{';
			$vw_job_board_custom_css .='text-align: '.esc_attr($vw_job_board_copyright_alingment).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_footer_padding = get_theme_mod('vw_job_board_footer_padding');
	if($vw_job_board_footer_padding != false){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='padding: '.esc_attr($vw_job_board_footer_padding).' 0;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_footer_background_image = get_theme_mod('vw_job_board_footer_background_image');
	if($vw_job_board_footer_background_image != false){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background: url('.esc_attr($vw_job_board_footer_background_image).');';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_footer_background_color = get_theme_mod('vw_job_board_footer_background_color');
	if($vw_job_board_footer_background_color != false){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background-color: '.esc_attr($vw_job_board_footer_background_color).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_img_footer','scroll');
	if($vw_job_board_theme_lay == 'fixed'){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background-attachment: fixed !important;';
		$vw_job_board_custom_css .='}';
	}elseif ($vw_job_board_theme_lay == 'scroll'){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background-attachment: scroll !important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_footer_img_position = get_theme_mod('vw_job_board_footer_img_position','center center');
	if($vw_job_board_footer_img_position != false){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background-position: '.esc_attr($vw_job_board_footer_img_position).'!important;';
		$vw_job_board_custom_css .='}';
	} 

	$vw_job_board_copyright_font_size = get_theme_mod('vw_job_board_copyright_font_size');
	if($vw_job_board_copyright_font_size != false){
		$vw_job_board_custom_css .='.copyright p, .copyright a{';
			$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_copyright_font_size).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_copyright_font_weight = get_theme_mod('vw_job_board_copyright_font_weight');
	if($vw_job_board_copyright_font_weight != false){
		$vw_job_board_custom_css .='.copyright p, .copyright a{';
			$vw_job_board_custom_css .='font-weight: '.esc_attr($vw_job_board_copyright_font_weight).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_copyright_text_color = get_theme_mod('vw_job_board_copyright_text_color');
	if($vw_job_board_copyright_text_color != false){
		$vw_job_board_custom_css .='.copyright p, .copyright a{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_copyright_text_color).';';
		$vw_job_board_custom_css .='}';
	} 

	/*------------------ Logo  -------------------*/

	$vw_job_board_logo_padding = get_theme_mod('vw_job_board_logo_padding');
	if($vw_job_board_logo_padding != false){
		$vw_job_board_custom_css .='.main-header .logo{';
			$vw_job_board_custom_css .='padding: '.esc_attr($vw_job_board_logo_padding).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_logo_margin = get_theme_mod('vw_job_board_logo_margin');
	if($vw_job_board_logo_margin != false){
		$vw_job_board_custom_css .='.main-header .logo{';
			$vw_job_board_custom_css .='margin: '.esc_attr($vw_job_board_logo_margin).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_site_title_font_size = get_theme_mod('vw_job_board_site_title_font_size');
	if($vw_job_board_site_title_font_size != false){
		$vw_job_board_custom_css .='.logo h1, .logo p.site-title{';
			$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_site_title_font_size).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_site_tagline_font_size = get_theme_mod('vw_job_board_site_tagline_font_size');
	if($vw_job_board_site_tagline_font_size != false){
		$vw_job_board_custom_css .='.logo p.site-description{';
			$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_site_tagline_font_size).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_site_title_color = get_theme_mod('vw_job_board_site_title_color');
	if($vw_job_board_site_title_color != false){
		$vw_job_board_custom_css .='p.site-title a{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_site_title_color).'!important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_site_tagline_color = get_theme_mod('vw_job_board_site_tagline_color');
	if($vw_job_board_site_tagline_color != false){
		$vw_job_board_custom_css .='.logo p.site-description{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_site_tagline_color).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_logo_width = get_theme_mod('vw_job_board_logo_width');
	if($vw_job_board_logo_width != false){
		$vw_job_board_custom_css .='.logo img{';
			$vw_job_board_custom_css .='width: '.esc_attr($vw_job_board_logo_width).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_logo_height = get_theme_mod('vw_job_board_logo_height');
	if($vw_job_board_logo_height != false){
		$vw_job_board_custom_css .='.logo img{';
			$vw_job_board_custom_css .='height: '.esc_attr($vw_job_board_logo_height).';';
		$vw_job_board_custom_css .='}';
	}

	// Woocommerce img

	$vw_job_board_shop_featured_image_border_radius = get_theme_mod('vw_job_board_shop_featured_image_border_radius', 0);
	if($vw_job_board_shop_featured_image_border_radius != false){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product a img{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_shop_featured_image_border_radius).'px;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_shop_featured_image_box_shadow = get_theme_mod('vw_job_board_shop_featured_image_box_shadow');
	if($vw_job_board_shop_featured_image_box_shadow != false){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product a img{';
				$vw_job_board_custom_css .='box-shadow: '.esc_attr($vw_job_board_shop_featured_image_box_shadow).'px '.esc_attr($vw_job_board_shop_featured_image_box_shadow).'px '.esc_attr($vw_job_board_shop_featured_image_box_shadow).'px #ddd;';
		$vw_job_board_custom_css .='}';
	}
 
	// Menus

	$vw_job_board_header_menus_color = get_theme_mod('vw_job_board_header_menus_color');
	if($vw_job_board_header_menus_color != false){
		$vw_job_board_custom_css .='.main-navigation a{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_header_menus_color).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_header_menus_hover_color = get_theme_mod('vw_job_board_header_menus_hover_color');
	if($vw_job_board_header_menus_hover_color != false){
		$vw_job_board_custom_css .='.main-navigation a:hover{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_header_menus_hover_color).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_header_submenus_color = get_theme_mod('vw_job_board_header_submenus_color');
	if($vw_job_board_header_submenus_color != false){
		$vw_job_board_custom_css .='.main-navigation ul ul a{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_header_submenus_color).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_header_submenus_hover_color = get_theme_mod('vw_job_board_header_submenus_hover_color');
	if($vw_job_board_header_submenus_hover_color != false){
		$vw_job_board_custom_css .='.main-navigation ul.sub-menu a:hover{';
			$vw_job_board_custom_css .='color: '.esc_attr($vw_job_board_header_submenus_hover_color).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_menus_item = get_theme_mod( 'vw_job_board_menus_item_style','None');
    if($vw_job_board_menus_item == 'None'){
		$vw_job_board_custom_css .='.main-navigation a{';
			$vw_job_board_custom_css .='';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_menus_item == 'Zoom In'){
		$vw_job_board_custom_css .='.main-navigation a:hover{';
			$vw_job_board_custom_css .='transition: all 0.3s ease-in-out !important; transform: scale(1.2) !important; color: #4a37f3;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_navigation_menu_font_weight = get_theme_mod('vw_job_board_navigation_menu_font_weight','500');
	if($vw_job_board_navigation_menu_font_weight != false){
		$vw_job_board_custom_css .='.main-navigation a{';
			$vw_job_board_custom_css .='font-weight: '.esc_attr($vw_job_board_navigation_menu_font_weight).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_menu_text_transform','Uppercase');
	if($vw_job_board_theme_lay == 'Capitalize'){
		$vw_job_board_custom_css .='.main-navigation a{';
			$vw_job_board_custom_css .='text-transform:Capitalize;';
		$vw_job_board_custom_css .='}';
	}
	if($vw_job_board_theme_lay == 'Lowercase'){
		$vw_job_board_custom_css .='.main-navigation a{';
			$vw_job_board_custom_css .='text-transform:Lowercase;';
		$vw_job_board_custom_css .='}';
	}
	if($vw_job_board_theme_lay == 'Uppercase'){
		$vw_job_board_custom_css .='.main-navigation a{';
			$vw_job_board_custom_css .='text-transform:Uppercase;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_navigation_menu_font_size = get_theme_mod('vw_job_board_navigation_menu_font_size');
	if($vw_job_board_navigation_menu_font_size != false){
		$vw_job_board_custom_css .='.main-navigation a{';
			$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_navigation_menu_font_size).';';
		$vw_job_board_custom_css .='}';
	}

	/*------------- Preloader Background Color  -------------------*/

	$vw_job_board_preloader_bg_color = get_theme_mod('vw_job_board_preloader_bg_color');
	if($vw_job_board_preloader_bg_color != false){
		$vw_job_board_custom_css .='#preloader{';
			$vw_job_board_custom_css .='background-color: '.esc_attr($vw_job_board_preloader_bg_color).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_preloader_border_color = get_theme_mod('vw_job_board_preloader_border_color');
	if($vw_job_board_preloader_border_color != false){
		$vw_job_board_custom_css .='.loader-line{';
			$vw_job_board_custom_css .='border-color: '.esc_attr($vw_job_board_preloader_border_color).'!important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_preloader_bg_img = get_theme_mod('vw_job_board_preloader_bg_img');
	if($vw_job_board_preloader_bg_img != false){
		$vw_job_board_custom_css .='#preloader{';
			$vw_job_board_custom_css .='background: url('.esc_attr($vw_job_board_preloader_bg_img).');-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;';
		$vw_job_board_custom_css .='}';
	}

	// Header Background Color

	$vw_job_board_header_background_color = get_theme_mod('vw_job_board_header_background_color');
	if($vw_job_board_header_background_color != false){
		$vw_job_board_custom_css .='.main-header{';
			$vw_job_board_custom_css .='background-color: '.esc_attr($vw_job_board_header_background_color).';';
		$vw_job_board_custom_css .='}';
	}

	/*------------- Slider CSS  -------------------*/

	if(get_theme_mod('vw_job_board_slider_hide_show') == true){
		$vw_job_board_custom_css .=' .page-template-custom-home-page .main-header{';
				$vw_job_board_custom_css .='border-bottom: 1px solid #000;';
		$vw_job_board_custom_css .='}';
	}

	/*------------- Copyright Border Radius CSS -------------------*/

    if(is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) || is_active_sidebar( 'footer-4' )){
		$vw_job_board_custom_css .='#footer-2{';
			$vw_job_board_custom_css .='border-top-left-radius: 0px;
    border-top-right-radius: 0px;';
		$vw_job_board_custom_css .='}';
	}

	/*---------------------------Slider Height ------------*/

	$vw_job_board_slider_height = get_theme_mod('vw_job_board_slider_height');
	if($vw_job_board_slider_height != false){
		$vw_job_board_custom_css .='#slider img{';
			$vw_job_board_custom_css .='height: '.esc_attr($vw_job_board_slider_height).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_related_product_show_hide = get_theme_mod('vw_job_board_related_product_show_hide',true);
	if($vw_job_board_related_product_show_hide != true){
		$vw_job_board_custom_css .='.related.products{';
			$vw_job_board_custom_css .='display: none;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_header_img_position = get_theme_mod('vw_job_board_header_img_position','center top');
	if($vw_job_board_header_img_position != false){
		$vw_job_board_custom_css .='.main-header{';
			$vw_job_board_custom_css .='background-position: '.esc_attr($vw_job_board_header_img_position).'!important;';
		$vw_job_board_custom_css .='}';
	} 

	/*--------------------- Grid Posts Posts -------------------*/

	$vw_job_board_display_grid_posts_settings = get_theme_mod( 'vw_job_board_display_grid_posts_settings','Into Blocks');
    if($vw_job_board_display_grid_posts_settings == 'Without Blocks'){
		$vw_job_board_custom_css .='.grid-post-main-box{';
			$vw_job_board_custom_css .='box-shadow: none; border: none; margin:30px 0;';
		$vw_job_board_custom_css .='}';
	}

	/*----------------Social Icons Settings ------------------*/

	$vw_job_board_social_icon_font_size = get_theme_mod('vw_job_board_social_icon_font_size');
	if($vw_job_board_social_icon_font_size != false){
		$vw_job_board_custom_css .='#sidebar .custom-social-icons i, #footer .custom-social-icons i{';
			$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_social_icon_font_size).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_social_icon_padding = get_theme_mod('vw_job_board_social_icon_padding');
	if($vw_job_board_social_icon_padding != false){
		$vw_job_board_custom_css .='#sidebar .custom-social-icons i, #footer .custom-social-icons i{';
			$vw_job_board_custom_css .='padding: '.esc_attr($vw_job_board_social_icon_padding).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_social_icon_width = get_theme_mod('vw_job_board_social_icon_width');
	if($vw_job_board_social_icon_width != false){
		$vw_job_board_custom_css .='#sidebar .custom-social-icons i, #footer .custom-social-icons i{';
			$vw_job_board_custom_css .='width: '.esc_attr($vw_job_board_social_icon_width).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_social_icon_height = get_theme_mod('vw_job_board_social_icon_height');
	if($vw_job_board_social_icon_height != false){
		$vw_job_board_custom_css .='#sidebar .custom-social-icons i, #footer .custom-social-icons i{';
			$vw_job_board_custom_css .='height: '.esc_attr($vw_job_board_social_icon_height).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_social_icon_border_radius = get_theme_mod('vw_job_board_social_icon_border_radius');
	if($vw_job_board_social_icon_border_radius != false){
		$vw_job_board_custom_css .='#sidebar .custom-social-icons i, #footer .custom-social-icons i{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_social_icon_border_radius).'px;';
		$vw_job_board_custom_css .='}';
	}

	/*---------------- Grid Posts Settings ------------------*/

	$vw_job_board_grid_featured_image_border_radius = get_theme_mod('vw_job_board_grid_featured_image_border_radius', 0);
	if($vw_job_board_grid_featured_image_border_radius != false){
		$vw_job_board_custom_css .='.grid-post-main-box .box-image img, .grid-post-main-box .feature-box img{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_grid_featured_image_border_radius).'px;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_grid_featured_image_box_shadow = get_theme_mod('vw_job_board_grid_featured_image_box_shadow',0);
	if($vw_job_board_grid_featured_image_box_shadow != false){
		$vw_job_board_custom_css .='.grid-post-main-box .box-image img, .grid-post-main-box #content-vw img{';
			$vw_job_board_custom_css .='box-shadow: '.esc_attr($vw_job_board_grid_featured_image_box_shadow).'px '.esc_attr($vw_job_board_grid_featured_image_box_shadow).'px '.esc_attr($vw_job_board_grid_featured_image_box_shadow).'px #cccccc;';
		$vw_job_board_custom_css .='}';
	}

	/*-------------- Sticky Header Padding ----------------*/

	$vw_job_board_sticky_header_padding = get_theme_mod('vw_job_board_sticky_header_padding');
	if($vw_job_board_sticky_header_padding != false){
		$vw_job_board_custom_css .='.header-fixed{';
			$vw_job_board_custom_css .='padding: '.esc_attr($vw_job_board_sticky_header_padding).'!important;';
		$vw_job_board_custom_css .='}';
	}

	/*---------------- Footer Settings ------------------*/

	$vw_job_board_button_footer_heading_letter_spacing = get_theme_mod('vw_job_board_button_footer_heading_letter_spacing',1);
	$vw_job_board_custom_css .='#footer h3, a.rsswidget.rss-widget-title{';
		$vw_job_board_custom_css .='letter-spacing: '.esc_attr($vw_job_board_button_footer_heading_letter_spacing).'px;';
	$vw_job_board_custom_css .='}';

	$vw_job_board_button_footer_font_size = get_theme_mod('vw_job_board_button_footer_font_size','25');
	$vw_job_board_custom_css .='#footer h3, a.rsswidget.rss-widget-title{';
		$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_button_footer_font_size).'px;';
	$vw_job_board_custom_css .='}';

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_button_footer_text_transform','Capitalize');
	if($vw_job_board_theme_lay == 'Capitalize'){
		$vw_job_board_custom_css .='#footer h3{';
			$vw_job_board_custom_css .='text-transform:Capitalize;';
		$vw_job_board_custom_css .='}';
	}
	if($vw_job_board_theme_lay == 'Lowercase'){
		$vw_job_board_custom_css .='#footer h3, a.rsswidget.rss-widget-title{';
			$vw_job_board_custom_css .='text-transform:Lowercase;';
		$vw_job_board_custom_css .='}';
	}
	if($vw_job_board_theme_lay == 'Uppercase'){
		$vw_job_board_custom_css .='#footer h3, a.rsswidget.rss-widget-title{';
			$vw_job_board_custom_css .='text-transform:Uppercase;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_footer_heading_weight = get_theme_mod('vw_job_board_footer_heading_weight','600');
	if($vw_job_board_footer_heading_weight != false){
		$vw_job_board_custom_css .='#footer h3, a.rsswidget.rss-widget-title{';
			$vw_job_board_custom_css .='font-weight: '.esc_attr($vw_job_board_footer_heading_weight).';';
		$vw_job_board_custom_css .='}';
	}

	/*---------------------------Footer Style -------------------*/

	$vw_job_board_theme_lay = get_theme_mod( 'vw_job_board_footer_template','vw_job_board-footer-one');
    if($vw_job_board_theme_lay == 'vw_job_board-footer-one'){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='';
		$vw_job_board_custom_css .='}';

	}else if($vw_job_board_theme_lay == 'vw_job_board-footer-two'){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background: linear-gradient(to right, #f9f8ff, #dedafa);';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#footer p, #footer li a, #footer, #footer h3, #footer a.rsswidget, #footer #wp-calendar a, .copyright a, #footer .custom_details, #footer ins span, #footer .tagcloud a, .main-inner-box span.entry-date a, nav.woocommerce-MyAccount-navigation ul li:hover a, #footer ul li a, #footer table, #footer th, #footer td, #footer caption, #sidebar caption,#footer nav.wp-calendar-nav a,#footer .search-form .search-field{';
			$vw_job_board_custom_css .='color:#000;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#footer ul li::before{';
			$vw_job_board_custom_css .='background:#000;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#footer table, #footer th, #footer td,#footer .search-form .search-field,#footer .tagcloud a{';
			$vw_job_board_custom_css .='border: 1px solid #000;';
		$vw_job_board_custom_css .='}';

	}else if($vw_job_board_theme_lay == 'vw_job_board-footer-three'){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background: #232524;';
		$vw_job_board_custom_css .='}';
	}
	else if($vw_job_board_theme_lay == 'vw_job_board-footer-four'){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background: #f7f7f7;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#footer p, #footer li a, #footer, #footer h3, #footer a.rsswidget, #footer #wp-calendar a, .copyright a, #footer .custom_details, #footer ins span, #footer .tagcloud a, .main-inner-box span.entry-date a, nav.woocommerce-MyAccount-navigation ul li:hover a, #footer ul li a, #footer table, #footer th, #footer td, #footer caption, #sidebar caption,#footer nav.wp-calendar-nav a,#footer .search-form .search-field{';
			$vw_job_board_custom_css .='color:#000;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#footer ul li::before{';
			$vw_job_board_custom_css .='background:#000;';
		$vw_job_board_custom_css .='}';
		$vw_job_board_custom_css .='#footer table, #footer th, #footer td,#footer .search-form .search-field,#footer .tagcloud a{';
			$vw_job_board_custom_css .='border: 1px solid #000;';
		$vw_job_board_custom_css .='}';
	}
	else if($vw_job_board_theme_lay == 'vw_job_board-footer-five'){
		$vw_job_board_custom_css .='#footer{';
			$vw_job_board_custom_css .='background: linear-gradient(to right, #01093a, #2d0b00);';
		$vw_job_board_custom_css .='}';
	}

	/*----------------Woocommerce Products Settings ------------------*/

	$vw_job_board_related_product_show_hide = get_theme_mod('vw_job_board_related_product_show_hide',true);
	if($vw_job_board_related_product_show_hide != true){
		$vw_job_board_custom_css .='.related.products{';
			$vw_job_board_custom_css .='display: none;';
		$vw_job_board_custom_css .='}';
	}

	/*----------------Woocommerce Products Settings ------------------*/

	$vw_job_board_products_padding_top_bottom = get_theme_mod('vw_job_board_products_padding_top_bottom');
	if($vw_job_board_products_padding_top_bottom != false){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$vw_job_board_custom_css .='padding-top: '.esc_attr($vw_job_board_products_padding_top_bottom).'!important; padding-bottom: '.esc_attr($vw_job_board_products_padding_top_bottom).'!important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_products_padding_left_right = get_theme_mod('vw_job_board_products_padding_left_right');
	if($vw_job_board_products_padding_left_right != false){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$vw_job_board_custom_css .='padding-left: '.esc_attr($vw_job_board_products_padding_left_right).'!important; padding-right: '.esc_attr($vw_job_board_products_padding_left_right).'!important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_products_box_shadow = get_theme_mod('vw_job_board_products_box_shadow');
	if($vw_job_board_products_box_shadow != false){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
				$vw_job_board_custom_css .='box-shadow: '.esc_attr($vw_job_board_products_box_shadow).'px '.esc_attr($vw_job_board_products_box_shadow).'px '.esc_attr($vw_job_board_products_box_shadow).'px #ddd;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_products_border_radius = get_theme_mod('vw_job_board_products_border_radius');
	if($vw_job_board_products_border_radius != false){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product, .woocommerce-page ul.products li.product{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_products_border_radius).'px;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_products_btn_padding_top_bottom = get_theme_mod('vw_job_board_products_btn_padding_top_bottom');
	if($vw_job_board_products_btn_padding_top_bottom != false){
		$vw_job_board_custom_css .='.woocommerce a.button{';
			$vw_job_board_custom_css .='padding-top: '.esc_attr($vw_job_board_products_btn_padding_top_bottom).' !important; padding-bottom: '.esc_attr($vw_job_board_products_btn_padding_top_bottom).' !important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_products_btn_padding_left_right = get_theme_mod('vw_job_board_products_btn_padding_left_right');
	if($vw_job_board_products_btn_padding_left_right != false){
		$vw_job_board_custom_css .='.woocommerce a.button{';
			$vw_job_board_custom_css .='padding-left: '.esc_attr($vw_job_board_products_btn_padding_left_right).' !important; padding-right: '.esc_attr($vw_job_board_products_btn_padding_left_right).' !important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_products_button_border_radius = get_theme_mod('vw_job_board_products_button_border_radius', 0);
	if($vw_job_board_products_button_border_radius != false){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product .button, a.checkout-button.button.alt.wc-forward,.woocommerce #respond input#submit, .woocommerce a.button, .woocommerce button.button, .woocommerce input.button, .woocommerce #respond input#submit.alt, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt,.woocommerce a.button{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_products_button_border_radius).'px !important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_woocommerce_sale_position = get_theme_mod( 'vw_job_board_woocommerce_sale_position','right');
    if($vw_job_board_woocommerce_sale_position == 'left'){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product .onsale{';
			$vw_job_board_custom_css .='left: 12px !important; right: auto !important;';
		$vw_job_board_custom_css .='}';
	}else if($vw_job_board_woocommerce_sale_position == 'right'){
		$vw_job_board_custom_css .='.woocommerce ul.products li.product .onsale{';
			$vw_job_board_custom_css .='left: auto!important; right: 0 !important;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_woocommerce_sale_font_size = get_theme_mod('vw_job_board_woocommerce_sale_font_size');
	if($vw_job_board_woocommerce_sale_font_size != false){
		$vw_job_board_custom_css .='.woocommerce span.onsale{';
			$vw_job_board_custom_css .='font-size: '.esc_attr($vw_job_board_woocommerce_sale_font_size).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_woocommerce_sale_padding_top_bottom = get_theme_mod('vw_job_board_woocommerce_sale_padding_top_bottom');
	if($vw_job_board_woocommerce_sale_padding_top_bottom != false){
		$vw_job_board_custom_css .='.woocommerce span.onsale{';
			$vw_job_board_custom_css .='padding-top: '.esc_attr($vw_job_board_woocommerce_sale_padding_top_bottom).'; padding-bottom: '.esc_attr($vw_job_board_woocommerce_sale_padding_top_bottom).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_woocommerce_sale_padding_left_right = get_theme_mod('vw_job_board_woocommerce_sale_padding_left_right');
	if($vw_job_board_woocommerce_sale_padding_left_right != false){
		$vw_job_board_custom_css .='.woocommerce span.onsale{';
			$vw_job_board_custom_css .='padding-left: '.esc_attr($vw_job_board_woocommerce_sale_padding_left_right).'; padding-right: '.esc_attr($vw_job_board_woocommerce_sale_padding_left_right).';';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_woocommerce_sale_border_radius = get_theme_mod('vw_job_board_woocommerce_sale_border_radius', 0);
	if($vw_job_board_woocommerce_sale_border_radius != false){
		$vw_job_board_custom_css .='.woocommerce span.onsale{';
			$vw_job_board_custom_css .='border-radius: '.esc_attr($vw_job_board_woocommerce_sale_border_radius).'px;';
		$vw_job_board_custom_css .='}';
	}

	$vw_job_board_responsive_preloader_hide = get_theme_mod('vw_job_board_responsive_preloader_hide',false);
	if($vw_job_board_responsive_preloader_hide == true && get_theme_mod('vw_job_board_loader_enable',false) == false){
		$vw_job_board_custom_css .='@media screen and (min-width:575px){
			#preloader{';
			$vw_job_board_custom_css .='display:none !important;';
		$vw_job_board_custom_css .='} }';
	}

	if($vw_job_board_responsive_preloader_hide == false){
		$vw_job_board_custom_css .='@media screen and (max-width:575px){
			#preloader{';
			$vw_job_board_custom_css .='display:none !important;';
		$vw_job_board_custom_css .='} }';
	}

	$vw_job_board_resp_topbar = get_theme_mod( 'vw_job_board_resp_topbar_hide_show',false);
	if($vw_job_board_resp_topbar == true && get_theme_mod( 'vw_job_board_topbar_hide_show', true) == false){
    	$vw_job_board_custom_css .='.topbar{';
			$vw_job_board_custom_css .='display:none;';
		$vw_job_board_custom_css .='} ';
	}
    if($vw_job_board_resp_topbar == true){
    	$vw_job_board_custom_css .='@media screen and (max-width:575px) {';
		$vw_job_board_custom_css .='.topbar{';
			$vw_job_board_custom_css .='display:block;';
		$vw_job_board_custom_css .='} }';
	}else if($vw_job_board_resp_topbar == false){
		$vw_job_board_custom_css .='@media screen and (max-width:575px) {';
		$vw_job_board_custom_css .='.topbar{';
			$vw_job_board_custom_css .='display:none;';
		$vw_job_board_custom_css .='} }';
	}

	$vw_job_board_bradcrumbs_alignment = get_theme_mod( 'vw_job_board_bradcrumbs_alignment','Left');
    if($vw_job_board_bradcrumbs_alignment == 'Left'){
    	$vw_job_board_custom_css .='@media screen and (min-width:768px) {';
		$vw_job_board_custom_css .='.bradcrumbs{';
			$vw_job_board_custom_css .='text-align:start;';
		$vw_job_board_custom_css .='}}';
	}else if($vw_job_board_bradcrumbs_alignment == 'Center'){
		$vw_job_board_custom_css .='@media screen and (min-width:768px) {';
		$vw_job_board_custom_css .='.bradcrumbs{';
			$vw_job_board_custom_css .='text-align:center;';
		$vw_job_board_custom_css .='}}';
	}else if($vw_job_board_bradcrumbs_alignment == 'Right'){
		$vw_job_board_custom_css .='@media screen and (min-width:768px) {';
		$vw_job_board_custom_css .='.bradcrumbs{';
			$vw_job_board_custom_css .='text-align:end;';
		$vw_job_board_custom_css .='}}';
	}