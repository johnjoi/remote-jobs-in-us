<?php
/**
 * The template part for Middle Header
 *
 * @package VW Job Board
 * @subpackage vw-job-board
 * @since vw-job-board 1.0
 */
?>

<div class="main-header <?php if( get_theme_mod( 'vw_job_board_sticky_header', false) == 1 || get_theme_mod( 'vw_job_board_stickyheader_hide_show', false) == 1) { ?> header-sticky"<?php } else { ?>close-sticky <?php } ?>">
    <div class="row">
      <div class="col-lg-3 col-md-5 col-12 logo-bg">
        <div class="logo text-md-start text-lg-start text-center">
          <?php if ( has_custom_logo() ) : ?>
            <div class="site-logo"><?php the_custom_logo(); ?></div>
          <?php endif; ?>
          <?php $blog_info = get_bloginfo( 'name' ); ?>
            <?php if ( ! empty( $blog_info ) ) : ?>
              <?php if ( is_front_page() && is_home() ) : ?>
                <?php if( get_theme_mod('vw_job_board_logo_title_hide_show',true) == 1){ ?>
                  <p class="site-title mb-0"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
                <?php } ?>
              <?php else : ?>
                <?php if( get_theme_mod('vw_job_board_logo_title_hide_show',true) == 1){ ?>
                  <p class="site-title mb-0"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
                <?php } ?>
              <?php endif; ?>
            <?php endif; ?>
            <?php
              $description = get_bloginfo( 'description', 'display' );
              if ( $description || is_customize_preview() ) :
            ?>
            <?php if( get_theme_mod('vw_job_board_tagline_hide_show',false) == 1){ ?>
              <p class="site-description mb-0">
                <?php echo esc_html($description); ?>
              </p>
            <?php } ?>
          <?php endif; ?>
        </div>
      </div>
      <div class="col-lg-6 col-md-2 col-4 align-self-center">
        <?php get_template_part('template-parts/header/navigation'); ?>
      </div>
      <div class="col-lg-1 col-md-2 col-2 align-self-center">
        <div class="search-box text-lg-end">
          <span><a href="#"><i class="<?php echo esc_attr(get_theme_mod('vw_job_board_searchopen_icon','fas fa-search')); ?>"></i></a></span>
        </div>
        <div class="serach_outer">
          <div class="closepop"><a href="#sidebar-pop"><i class="<?php echo esc_attr(get_theme_mod('vw_job_board_searchclose_icon','fas fa-window-close')); ?>"></i></a></div>
          <div class="serach_inner">
            <?php get_search_form(); ?>
          </div>
        </div>
      </div>
      <div class="col-lg-2 col-md-3 col-6 align-self-center">
        <div class="header-btn text-lg-end text-md-end py-3 py-md-0">
          <?php if( get_theme_mod('vw_job_board_header_btn_link') != '' || get_theme_mod('vw_job_board_header_btn_text') != '' ){ ?>
            <a href="<?php echo esc_url(get_theme_mod('vw_job_board_header_btn_link',''));?>"><?php echo esc_html(get_theme_mod('vw_job_board_header_btn_text',''));?></a>
          <?php }?>
        </div>
      </div>
    </div>
</div>