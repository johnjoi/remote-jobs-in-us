<?php
/**
 * The template part for top header
 *
 * @package VW Job Board
 * @subpackage vw-job-board
 * @since vw-job-board 1.0
 */
?>

<?php if( get_theme_mod( 'vw_job_board_topbar_hide_show', true) == 1 || get_theme_mod( 'vw_job_board_resp_topbar_hide_show', false) == 1) { ?>
  <div class="topbar py-2">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-4 col-12 mb-3 mb-md-0 mb-lg-0 text-center text-lg-start text-md-start align-self-center">
          <?php if( get_theme_mod('vw_job_board_topbar_email_text') != '' ){ ?>
            <span class="email-text me-2"><?php echo esc_html(get_theme_mod('vw_job_board_topbar_email_text',''));?></span>
          <?php }?>
          <?php if( get_theme_mod('vw_job_board_topbar_email') != '' ){ ?>
            <span class="email"><i class="<?php echo esc_attr(get_theme_mod('vw_job_board_mail_icon','fas fa-envelope')); ?>"></i><a href="mailto:<?php echo esc_attr(get_theme_mod('vw_job_board_topbar_email',''));?>"><?php echo esc_html(get_theme_mod('vw_job_board_topbar_email',''));?></a></span>

          <?php }?>
        </div>
        <div class="col-lg-4 col-md-4 col-12 mb-3 mb-md-0 mb-lg-0 text-center align-self-center">
          <?php if( get_theme_mod('vw_job_board_topbar_consultation_text') != '' ){ ?>
            <span><?php echo esc_html(get_theme_mod('vw_job_board_topbar_consultation_text',''));?></span>
          <?php }?>
        </div>
        <div class="col-lg-4 col-md-4 col-12 mb-3 mb-md-0 mb-lg-0 text-center text-lg-end text-md-end align-self-center">
          <div class="social-icons">
            <?php dynamic_sidebar('topbar-social-icons'); ?>
          </div>
        </div>
      </div>
    </div>
  </div>
<?php } ?>