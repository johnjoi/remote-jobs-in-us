<?php
/**
 * Template Name: Custom Home Page
 */

get_header(); ?>

<main id="maincontent" role="main">
  <?php do_action( 'vw_job_board_before_slider' ); ?>

  <?php if( get_theme_mod( 'vw_job_board_slider_hide_show', true) == 1 || get_theme_mod( 'vw_job_board_resp_slider_hide_show', false) == 1) { ?>
    <?php if(get_theme_mod('vw_job_board_slider_type', 'Default slider') == 'Default slider' ){ ?>
      <section id="slider">        
        <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel" data-bs-interval="<?php echo esc_attr(get_theme_mod( 'vw_job_board_slider_speed',4000)) ?>">
          <?php $vw_job_board_pages = array();
            for ( $count = 1; $count <= 3; $count++ ) {
              $mod = intval( get_theme_mod( 'vw_job_board_slider_page' . $count ));
              if ( 'page-none-selected' != $mod ) {
                $vw_job_board_pages[] = $mod;
              }
            }
            if( !empty($vw_job_board_pages) ) :
              $args = array(
                'post_type' => 'page',
                'post__in' => $vw_job_board_pages,
                'orderby' => 'post__in'
              );
              $query = new WP_Query( $args );
              if ( $query->have_posts() ) :
                $i = 1;
          ?>
          <div class="carousel-inner" role="listbox">
            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
              <div <?php if($i == 1){echo 'class="carousel-item active"';} else{ echo 'class="carousel-item"';}?>>
                <?php if(has_post_thumbnail()){
                  the_post_thumbnail();
                } else{?>
                  <img src="<?php echo esc_url(get_template_directory_uri()); ?>/inc/block-patterns/images/banner1.png" alt="" />
                <?php } ?>
                <div class="carousel-caption">
                  <div class="inner_carousel">
                    <h1 class="wow rollIn delay-1000" data-wow-duration="2s"><a href="<?php echo esc_url( get_permalink() ); ?>" title="<?php echo the_title_attribute(); ?>"><?php the_title(); ?></a></h1>
                    <p class="wow rollIn delay-1000" data-wow-duration="2s"><?php $vw_job_board_excerpt = get_the_excerpt(); echo esc_html( vw_job_board_string_limit_words( $vw_job_board_excerpt, esc_attr(get_theme_mod('vw_job_board_slider_excerpt_number','30')))); ?></p>
                    <div class="slide-search wow rollIn delay-1000" data-wow-duration="2s">
                      <?php get_search_form(); ?>
                    </div>
                  </div>
                </div>
              </div>
            <?php $i++; endwhile; 
            wp_reset_postdata();?>
          </div>
          <?php else : ?>
            <div class="no-postfound"></div>
          <?php endif;
          endif;?>
          <?php if(get_theme_mod('vw_job_board_slider_arrow_hide_show', true)){?>
            <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleInterval" id="prev" data-bs-slide="prev">
            <i class="<?php echo esc_attr(get_theme_mod('vw_job_board_slider_prev_icon','fas fa-angle-left')); ?>"></i>
            <span class="screen-reader-text"><?php echo esc_html(__('Previous','vw-job-board')); ?></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleInterval" data-bs-slide="next" id="next">
            <i class="<?php echo esc_attr(get_theme_mod('vw_job_board_slider_next_icon','fas fa-angle-right')); ?>"></i>
            <span class="screen-reader-text"><?php echo esc_html(__('Next','vw-job-board')); ?></span>
            </button>
          <?php }?>
        </div> 
    </section>
    <?php } else if(get_theme_mod('vw_job_board_slider_type', 'Advance slider') == 'Advance slider'){?>
      <?php echo do_shortcode(get_theme_mod('vw_job_board_advance_slider_shortcode')); ?>
    <?php } ?>
  <?php }?>

  <?php do_action( 'vw_job_board_after_slider' ); ?>

  <?php if( get_theme_mod( 'vw_job_board_featured_small_title')|| get_theme_mod( 'vw_job_board_featured_heading') || get_theme_mod( 'vw_job_board_featured_category')) { ?>
    <section id="featured-job-section" class="pt-5 wow bounceInDown delay-1000" data-wow-duration="3s">
      <div class="container-fluid px-0">
        <?php if( get_theme_mod('vw_job_board_featured_small_title') != '' ){ ?>
          <strong class="text-center d-block mb-1"><?php echo esc_html(get_theme_mod('vw_job_board_featured_small_title',''));?></strong>
        <?php }?>
        <?php if( get_theme_mod('vw_job_board_featured_heading') != '' ){ ?>
          <h2 class="text-center heading-text"><?php echo esc_html(get_theme_mod('vw_job_board_featured_heading',''));?></h2>
        <?php }?>
        <div class="featured-category-box pt-4">
          <div class="row">
            <?php
              $vw_job_board_catdata=  get_theme_mod('vw_job_board_featured_category');
              if($vw_job_board_catdata){
            $page_query = new WP_Query(array( 'category_name' => esc_html($vw_job_board_catdata ,'vw-job-board'))); ?>         
              <?php while( $page_query->have_posts() ) : $page_query->the_post(); ?>
                <div class="col-lg-6 col-md-6 align-self-center mb-4">
                  <div class="catgory-box p-4">
                    <div class="row">
                      <div class="col-lg-1 col-md-3 align-self-center">
                        <?php the_post_thumbnail(); ?>
                      </div>
                      <div class="col-lg-9 col-md-9 align-self-center">
                        <h3 class="mt-3 mt-md-0 mt-lg-0"><a href="<?php the_permalink(); ?>"><?php the_title(); ?><span class="screen-reader-text"><?php the_title(); ?></span></a></h3>
                        <?php if( get_post_meta($post->ID, 'vw_job_board_technology', true) ) {?>
                          <div class="technology-meta-fields">
                            <?php if( get_post_meta($post->ID, 'vw_job_board_technology', true) ) {?>
                              <span class="technology"><?php echo esc_html(get_post_meta($post->ID,'vw_job_board_technology',true)); ?></span>
                            <?php }?>
                          </div>
                        <?php }?>
                      </div>
                    </div>

                    <p class="pt-2 pt-md-3 pt-lg-3"><?php $vw_job_board_excerpt = get_the_excerpt(); echo esc_html( vw_job_board_string_limit_words( $vw_job_board_excerpt, esc_attr(get_theme_mod('vw_job_board_services_excerpt_number','30')))); ?></p>
                      
                    <?php if( get_post_meta($post->ID, 'vw_job_board_feature1', true) ) {?>
                      <span class="features-meta-fields text-center p-1">
                        <?php if( get_post_meta($post->ID, 'vw_job_board_feature1', true) ) {?>
                          <span class="features"><?php echo esc_html(get_post_meta($post->ID,'vw_job_board_feature1',true)); ?></span>
                        <?php }?>
                      </span>
                    <?php }?>
                    <?php if( get_post_meta($post->ID, 'vw_job_board_feature2', true) ) {?>
                      <span class="features-meta-fields text-center p-1">
                        <?php if( get_post_meta($post->ID, 'vw_job_board_feature2', true) ) {?>
                          <span class="features"><?php echo esc_html(get_post_meta($post->ID,'vw_job_board_feature2',true)); ?></span>
                        <?php }?>
                      </span>
                    <?php }?>
                    <?php if( get_post_meta($post->ID, 'vw_job_board_feature3', true) ) {?>
                      <span class="features-meta-fields text-center p-1">
                        <?php if( get_post_meta($post->ID, 'vw_job_board_feature3', true) ) {?>
                          <span class="features"><?php echo esc_html(get_post_meta($post->ID,'vw_job_board_feature3',true)); ?></span>
                        <?php }?>
                      </span>
                    <?php }?>
                    <?php if( get_post_meta($post->ID, 'vw_job_board_feature4', true) ) {?>
                      <span class="features-meta-fields text-center p-1">
                        <?php if( get_post_meta($post->ID, 'vw_job_board_feature4', true) ) {?>
                          <span class="features"><?php echo esc_html(get_post_meta($post->ID,'vw_job_board_feature4',true)); ?></span>
                        <?php }?>
                      </span>
                    <?php }?>

                    <hr class="cat-features">  
                    
                    <div class="prices pt-2">
                      <div class="row">
                        <div class="col-lg-8 col-md-12 col-12 align-self-center">
                          <?php if( get_post_meta($post->ID, 'vw_job_board_price', true) ) {?>
                            <span class="secondary-meta-fields">
                              <?php if( get_post_meta($post->ID, 'vw_job_board_price', true) ) {?>
                                <span class="prices"><i class="fas fa-dollar-sign"></i> <?php echo esc_html(get_post_meta($post->ID,'vw_job_board_price',true)); ?></span>
                              <?php }?>
                            </span>
                          <?php }?>

                          <?php if( get_post_meta($post->ID, 'vw_job_board_applicants', true) ) {?>
                            <span class="secondary-meta-fields">
                              <?php if( get_post_meta($post->ID, 'vw_job_board_applicants', true) ) {?>
                                <span class="apllicant"><i class="fas fa-users"></i> <?php echo esc_html(get_post_meta($post->ID,'vw_job_board_applicants',true)); ?></span>
                              <?php }?>
                            </span>
                          <?php }?>
                        </div>

                        <div class="col-lg-4 col-md-12 col-12 align-self-center">
                          <div class="featured-cat-btn text-lg-end text-md-start text-start mt-lg-0 mt-md-4 mt-4">
                            <a href="<?php the_permalink();?>"><?php esc_html_e('APPLY NOW','vw-job-board'); ?><span class="screen-reader-text"><?php esc_html_e('APPLY NOW','vw-job-board'); ?></span></a>
                          </div>
                        </div>
                      </div>                    
                    </div> 
                  </div>
                </div>
              <?php endwhile;
              wp_reset_postdata();}
            ?>
          </div>
        </div>
      </div>
    </section>
  <?php }?>

  <?php do_action( 'vw_job_board_after_featured_job' ); ?>

  <div id="content-vw" class="py-3">
    <div class="container-fluid">
      <?php while ( have_posts() ) : the_post(); ?>
        <?php the_content(); ?>
      <?php endwhile; // end of the loop. ?>
    </div>
  </div>
</main>

<?php get_footer(); ?>