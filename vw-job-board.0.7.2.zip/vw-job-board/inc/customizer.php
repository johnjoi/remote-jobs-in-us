<?php
/**
 * VW Job Board Theme Customizer
 *
 * @package VW Job Board
 */

/**
 * Add postMessage support for site title and description for the Theme Customizer.
 *
 * @param WP_Customize_Manager $wp_customize Theme Customizer object.
 */

function vw_job_board_custom_controls() {
	load_template( trailingslashit( get_template_directory() ) . '/inc/custom-controls.php' );
}
add_action( 'customize_register', 'vw_job_board_custom_controls' );

function vw_job_board_customize_register( $wp_customize ) {

	load_template( trailingslashit( get_template_directory() ) . '/inc/icon-picker.php' );

	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage'; 
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial( 'blogname', array( 
		'selector' => '.logo .site-title a', 
	 	'render_callback' => 'vw_job_board_Customize_partial_blogname',
	)); 

	$wp_customize->selective_refresh->add_partial( 'blogdescription', array( 
		'selector' => 'p.site-description', 
		'render_callback' => 'vw_job_board_Customize_partial_blogdescription',
	));

	//Homepage Settings
	$wp_customize->add_panel( 'vw_job_board_homepage_panel', array(
		'title' => esc_html__( 'Homepage Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_panel_id',
		'priority' => 20,
	));

	//Topbar
	$wp_customize->add_section( 'vw_job_board_topbar_section' , array(
    	'title' => __( 'Topbar Section', 'vw-job-board' ),
		'panel' => 'vw_job_board_homepage_panel'
	) );

 	// Header Background color
	$wp_customize->add_setting('vw_job_board_header_background_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_header_background_color', array(
		'label'    => __('Header Background Color', 'vw-job-board'),
		'section'  => 'header_image',
	)));

	$wp_customize->add_setting('vw_job_board_header_img_position',array(
	  'default' => 'center top',
	  'transport' => 'refresh',
	  'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_header_img_position',array(
		'type' => 'select',
		'label' => __('Header Image Position','vw-job-board'),
		'section' => 'header_image',
		'choices' 	=> array(
			'left top' 		=> esc_html__( 'Top Left', 'vw-job-board' ),
			'center top'   => esc_html__( 'Top', 'vw-job-board' ),
			'right top'   => esc_html__( 'Top Right', 'vw-job-board' ),
			'left center'   => esc_html__( 'Left', 'vw-job-board' ),
			'center center'   => esc_html__( 'Center', 'vw-job-board' ),
			'right center'   => esc_html__( 'Right', 'vw-job-board' ),
			'left bottom'   => esc_html__( 'Bottom Left', 'vw-job-board' ),
			'center bottom'   => esc_html__( 'Bottom', 'vw-job-board' ),
			'right bottom'   => esc_html__( 'Bottom Right', 'vw-job-board' ),
		),
	));

	$wp_customize->add_setting( 'vw_job_board_topbar_hide_show',array(
	  'default' => 1,
	  'transport' => 'refresh',
	  'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ));  
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_topbar_hide_show',array(
    'label' => esc_html__( 'Show / Hide Topbar','vw-job-board' ),
    'section' => 'vw_job_board_topbar_section'
  )));

	$wp_customize->add_setting('vw_job_board_searchopen_icon',array(
		'default'	=> 'fas fa-search',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_searchopen_icon',array(
		'label'	=> __('Add Search Open Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_topbar_section',
		'setting'	=> 'vw_job_board_searchopen_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting('vw_job_board_searchclose_icon',array(
		'default'	=> 'fas fa-window-close',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_searchclose_icon',array(
		'label'	=> __('Add Search Close Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_topbar_section',
		'setting'	=> 'vw_job_board_searchclose_icon',
		'type'		=> 'icon'
	)));

	//Sticky Header
	$wp_customize->add_setting( 'vw_job_board_sticky_header',array(
      'default' => 0,
      'transport' => 'refresh',
      'sanitize_callback' => 'vw_job_board_switch_sanitization'
	) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_sticky_header',array(
	  'label' => esc_html__( 'Sticky Header','vw-job-board' ),
	  'section' => 'vw_job_board_topbar_section'
	)));

	$wp_customize->add_setting('vw_job_board_sticky_header_padding',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_sticky_header_padding',array(
		'label'	=> __('Sticky Header Padding','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_topbar_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_topbar_email_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_topbar_email_text',array(
		'label'	=> esc_html__('Add Email Text','vw-job-board'),
		'input_attrs' => array(
        'placeholder' => esc_html__( 'Write Us Here!', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_topbar_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_topbar_email',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_email'
	));
	$wp_customize->add_control('vw_job_board_topbar_email',array(
		'label'	=> __('Add Email Address','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'example@gmail.com', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_topbar_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_mail_icon',array(
		'default'	=> 'fas fa-envelope',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_mail_icon',array(
		'label'	=> __('Add Mail Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_topbar_section',
		'setting'	=> 'vw_job_board_mail_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting('vw_job_board_topbar_consultation_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_topbar_consultation_text',array(
		'label'	=> esc_html__('Add Consultation Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'Get Free Job Consultation', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_topbar_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_header_btn_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_header_btn_text',array(
		'label'	=> esc_html__('Add Button Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'APPLY FOR JOB', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_topbar_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_header_btn_link',array(
		'default'=> '',
		'sanitize_callback'	=> 'esc_url_raw'
	));
	$wp_customize->add_control('vw_job_board_header_btn_link',array(
		'label'	=> esc_html__('Add Button Link','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'www.example-info.com', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_topbar_section',
		'type'=> 'url'
	));

	//Menus Settings
	$wp_customize->add_section( 'vw_job_board_menu_section' , array(
    	'title' => __( 'Menus Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_homepage_panel'
	) );

	$wp_customize->add_setting('vw_job_board_navigation_menu_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_navigation_menu_font_size',array(
		'label'	=> __('Menus Font Size','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_menu_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_navigation_menu_font_weight',array(
        'default' => 500,
        'transport' => 'refresh',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_navigation_menu_font_weight',array(
        'type' => 'select',
        'label' => __('Menus Font Weight','vw-job-board'),
        'section' => 'vw_job_board_menu_section',
        'choices' => array(
        	'100' => __('100','vw-job-board'),
            '200' => __('200','vw-job-board'),
            '300' => __('300','vw-job-board'),
            '400' => __('400','vw-job-board'),
            '500' => __('500','vw-job-board'),
            '600' => __('600','vw-job-board'),
            '700' => __('700','vw-job-board'),
            '800' => __('800','vw-job-board'),
            '900' => __('900','vw-job-board'),
        ),
	) );

	// text trasform
	$wp_customize->add_setting('vw_job_board_menu_text_transform',array(
		'default'=> 'Uppercase',
		'sanitize_callback'	=> 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_menu_text_transform',array(
		'type' => 'radio',
		'label'	=> __('Menu Text Transform','vw-job-board'),
		'choices' => array(
            'Uppercase' => __('Uppercase','vw-job-board'),
            'Capitalize' => __('Capitalize','vw-job-board'),
            'Lowercase' => __('Lowercase','vw-job-board'),
        ),
		'section'=> 'vw_job_board_menu_section',
	));

	$wp_customize->add_setting('vw_job_board_menus_item_style',array(
    'default' => '',
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_menus_item_style',array(
		'type' => 'select',
		'section' => 'vw_job_board_menu_section',
		'label' => __('Menu Item Hover Style','vw-job-board'),
		'choices' => array(
		    'None' => __('None','vw-job-board'),
		    'Zoom In' => __('Zoom In','vw-job-board'),
        ),
	) );

	$wp_customize->add_setting('vw_job_board_header_menus_color', array(
		'default'           => '#000000',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_header_menus_color', array(
		'label'    => __('Menus Color', 'vw-job-board'),
		'section'  => 'vw_job_board_menu_section',
	)));

	$wp_customize->add_setting('vw_job_board_header_menus_hover_color', array(
		'default'           => '#4a37f3',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_header_menus_hover_color', array(
		'label'    => __('Menus Hover Color', 'vw-job-board'),
		'section'  => 'vw_job_board_menu_section',
	)));

	$wp_customize->add_setting('vw_job_board_header_submenus_color', array(
		'default'           => '#222',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_header_submenus_color', array(
		'label'    => __('Sub Menus Color', 'vw-job-board'),
		'section'  => 'vw_job_board_menu_section',
	)));

	$wp_customize->add_setting('vw_job_board_header_submenus_hover_color', array(
		'default'           => '#4a37f3',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_header_submenus_hover_color', array(
		'label'    => __('Sub Menus Hover Color', 'vw-job-board'),
		'section'  => 'vw_job_board_menu_section',
	)));

	//Social links
	$wp_customize->add_section(
		'vw_job_board_social_links', array(
			'title'		=>	__('Social Links', 'vw-job-board'),
			'priority'	=>	null,
			'panel'		=>	'vw_job_board_homepage_panel'
		));

	$wp_customize->add_setting('vw_job_board_social_icons',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_social_icons',array(
		'label' =>  __('Steps to setup social icons','vw-job-board'),
		'description' => __('<p>1. Go to Dashboard >> Appearance >> Widgets</p>
			<p>2. Add Vw Social Icon Widget in Topbar Social Icons.</p>
			<p>3. Add social icons url and save.</p>','vw-job-board'),
		'section'=> 'vw_job_board_social_links',
		'type'=> 'hidden'
	));
	$wp_customize->add_setting('vw_job_board_social_icon_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_social_icon_btn',array(
		'description' => "<a target='_blank' href='". admin_url('widgets.php') ." '>Setup Social Icons</a>",
		'section'=> 'vw_job_board_social_links',
		'type'=> 'hidden'
	));

	//Slider
	$wp_customize->add_section( 'vw_job_board_slidersettings' , array(
    	'title'      => __( 'Slider Settings', 'vw-job-board' ),
    	'description' => __('Free theme has 3 slides options, For unlimited slides and more options </br> <a class="go-pro-btn" target="blank" href="https://www.vwthemes.com/products/job-portal-wordpress-theme">GO PRO</a>','vw-job-board'),
		'panel' => 'vw_job_board_homepage_panel'
	) );

	$wp_customize->add_setting( 'vw_job_board_slider_hide_show',array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ));  
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_slider_hide_show',array(
    'label' => esc_html__( 'Show / Hide Slider','vw-job-board' ),
    'section' => 'vw_job_board_slidersettings'
  )));

  $wp_customize->add_setting('vw_job_board_slider_type',array(
    'default' => 'Default slider',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	) );
	$wp_customize->add_control('vw_job_board_slider_type', array(
      'type' => 'select',
      'label' => __('Slider Type','vw-job-board'),
      'section' => 'vw_job_board_slidersettings',
      'choices' => array(
          'Default slider' => __('Default slider','vw-job-board'),
          'Advance slider' => __('Advance slider','vw-job-board'),
        ),
	));

	$wp_customize->add_setting('vw_job_board_advance_slider_shortcode',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_advance_slider_shortcode',array(
		'label'	=> __('Add Slider Shortcode','vw-job-board'),
		'section'=> 'vw_job_board_slidersettings',
		'type'=> 'text',
		'active_callback' => 'vw_job_board_advance_slider'
	));

  //Selective Refresh
  $wp_customize->selective_refresh->add_partial('vw_job_board_slider_hide_show',array(
		'selector'        => '.slider-btn a',
		'render_callback' => 'vw_job_board_customize_partial_vw_job_board_slider_hide_show',
	));

	for ( $count = 1; $count <= 3; $count++ ) {
		$wp_customize->add_setting( 'vw_job_board_slider_page' . $count, array(
			'default'           => '',
			'sanitize_callback' => 'vw_job_board_sanitize_dropdown_pages'
		) );
		$wp_customize->add_control( 'vw_job_board_slider_page' . $count, array(
			'label'    => __( 'Select Slider Page', 'vw-job-board' ),
			'description' => __('Slider image size (1400 x 550)','vw-job-board'),
			'section'  => 'vw_job_board_slidersettings',
			'type'     => 'dropdown-pages',
			'active_callback' => 'vw_job_board_default_slider'
		) );
	}

	//content layout
	$wp_customize->add_setting('vw_job_board_slider_content_option',array(
        'default' => 'Left',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control(new VW_Job_Board_Image_Radio_Control($wp_customize, 'vw_job_board_slider_content_option', array(
        'type' => 'select',
        'label' => __('Slider Content Layouts','vw-job-board'),
        'section' => 'vw_job_board_slidersettings',
        'choices' => array(
            'Left' => esc_url(get_template_directory_uri()).'/assets/images/slider-content1.png',
            'Center' => esc_url(get_template_directory_uri()).'/assets/images/slider-content2.png',
            'Right' => esc_url(get_template_directory_uri()).'/assets/images/slider-content3.png',
    ),'active_callback' => 'vw_job_board_default_slider'
    )));

	$wp_customize->add_setting( 'vw_job_board_slider_speed', array(
		'default'  => 4000,
		'sanitize_callback'	=> 'sanitize_text_field'
	) );
	$wp_customize->add_control( 'vw_job_board_slider_speed', array(
		'label' => esc_html__('Slider Transition Speed','vw-job-board'),
		'section' => 'vw_job_board_slidersettings',
		'type'  => 'text',
		'active_callback' => 'vw_job_board_default_slider'
	) );

		//Slider height
	$wp_customize->add_setting('vw_job_board_slider_height',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_slider_height',array(
		'label'	=> __('Slider Height','vw-job-board'),
		'description'	=> __('Specify the slider height (px).','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '500px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_slidersettings',
		'type'=> 'text',
		'active_callback' => 'vw_job_board_default_slider'
	));

	//Opacity
	$wp_customize->add_setting('vw_job_board_slider_opacity_color',array(
      'default'              => 0.8,
      'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));

	$wp_customize->add_control( 'vw_job_board_slider_opacity_color', array(
	'label'       => esc_html__( 'Slider Image Opacity','vw-job-board' ),
	'section'     => 'vw_job_board_slidersettings',
	'type'        => 'select',
	'settings'    => 'vw_job_board_slider_opacity_color',
	'choices' => array(
      '0' =>  esc_attr( __('0','vw-job-board')),
      '0.1' =>  esc_attr( __('0.1','vw-job-board')),
      '0.2' =>  esc_attr( __('0.2','vw-job-board')),
      '0.3' =>  esc_attr( __('0.3','vw-job-board')),
      '0.4' =>  esc_attr( __('0.4','vw-job-board')),
      '0.5' =>  esc_attr( __('0.5','vw-job-board')),
      '0.6' =>  esc_attr( __('0.6','vw-job-board')),
      '0.7' =>  esc_attr( __('0.7','vw-job-board')),
      '0.8' =>  esc_attr( __('0.8','vw-job-board')),
      '0.9' =>  esc_attr( __('0.9','vw-job-board'))
	),'active_callback' => 'vw_job_board_default_slider'
	));

	$wp_customize->add_setting( 'vw_job_board_slider_image_overlay',array(
    	'default' => 1,
      	'transport' => 'refresh',
      	'sanitize_callback' => 'vw_job_board_switch_sanitization'
   ));
   $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_slider_image_overlay',array(
      	'label' => esc_html__( 'Show / Hide Slider Image Overlay','vw-job-board' ),
      	'section' => 'vw_job_board_slidersettings',
      	'active_callback' => 'vw_job_board_default_slider'
   )));

   $wp_customize->add_setting('vw_job_board_slider_image_overlay_color', array(
		'default'           => '#000',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_slider_image_overlay_color', array(
		'label'    => __('Slider Image Overlay Color', 'vw-job-board'),
		'section'  => 'vw_job_board_slidersettings',
		'active_callback' => 'vw_job_board_default_slider'
	)));

	$wp_customize->add_setting( 'vw_job_board_slider_arrow_hide_show',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'vw_job_board_switch_sanitization'
	));
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_slider_arrow_hide_show',array(
		'label' => esc_html__( 'Show / Hide Slider Arrows','vw-job-board' ),
		'section' => 'vw_job_board_slidersettings',
		'active_callback' => 'vw_job_board_default_slider'
	)));

	$wp_customize->add_setting('vw_job_board_slider_prev_icon',array(
		'default'	=> 'fas fa-angle-left',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_slider_prev_icon',array(
		'label'	=> __('Add Slider Prev Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_slidersettings',
		'setting'	=> 'vw_job_board_slider_prev_icon',
		'type'		=> 'icon',
		'active_callback' => 'vw_job_board_default_slider'
	)));

	$wp_customize->add_setting('vw_job_board_slider_next_icon',array(
		'default'	=> 'fas fa-angle-right',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_slider_next_icon',array(
		'label'	=> __('Add Slider Next Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_slidersettings',
		'setting'	=> 'vw_job_board_slider_next_icon',
		'type'		=> 'icon',
		'active_callback' => 'vw_job_board_default_slider'
	)));

	//Job Categories Section
	$wp_customize->add_section('vw_job_board_job_categories', array(
		'title'       => __('Job Categories Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_job_categories_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_job_categories_text',array(
		'description' => __('<p>1. More options for job categories section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for job categories section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_job_categories',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_job_categories_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_job_categories_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_job_categories',
		'type'=> 'hidden'
	));

	//How it Works Section
	$wp_customize->add_section('vw_job_board_how_it_works', array(
		'title'       => __('How it Works Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_how_it_works_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_how_it_works_text',array(
		'description' => __('<p>1. More options for how it works section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for how it works section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_how_it_works',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_how_it_works_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_how_it_works_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_how_it_works',
		'type'=> 'hidden'
	));

	//Upload Resume Section
	$wp_customize->add_section('vw_job_board_upload_resume', array(
		'title'       => __('Upload Resume Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_upload_resume_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_upload_resume_text',array(
		'description' => __('<p>1. More options for upload resume section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for upload resume section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_upload_resume',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_upload_resume_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_upload_resume_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_upload_resume',
		'type'=> 'hidden'
	));

	// Featured Job Section
	$wp_customize->add_section('vw_job_board_featured_job_section',array(
		'title'	=> __('Featured Job Section','vw-job-board'),
		'description' => __('For more options of the Featured Job Section</br> <a class="go-pro-btn" target="blank" href="https://www.vwthemes.com/products/job-portal-wordpress-theme">GO PRO</a>','vw-job-board'),
		'panel' => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting( 'vw_job_board_featured_small_title', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	$wp_customize->add_control( 'vw_job_board_featured_small_title', array(
		'label'    => __( 'Add Section Small Title', 'vw-job-board' ),
		'input_attrs' => array(
            'placeholder' => __( 'FEATURED JOBS', 'vw-job-board' ),
        ),
		'section'  => 'vw_job_board_featured_job_section',
		'type'     => 'text'
	) );

	$wp_customize->add_setting( 'vw_job_board_featured_heading', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_text_field'
	) );
	$wp_customize->add_control( 'vw_job_board_featured_heading', array(
		'label'    => __( 'Add Section Heading', 'vw-job-board' ),
		'input_attrs' => array(
            'placeholder' => __( 'Look Into Our Featured Jobs', 'vw-job-board' ),
        ),
		'section'  => 'vw_job_board_featured_job_section',
		'type'     => 'text'
	) );

	$categories = get_categories();
	$cat_post = array();
	$cat_post[]= 'select';
	$i = 0;	
	foreach($categories as $category){
		if($i==0){
			$default = $category->slug;
			$i++;
		}
		$cat_post[$category->slug] = $category->name;
	}

	$wp_customize->add_setting('vw_job_board_featured_category',array(
		'default'	=> 'select',
		'sanitize_callback' => 'vw_job_board_sanitize_choices',
	));
	$wp_customize->add_control('vw_job_board_featured_category',array(
		'type'    => 'select',
		'choices' => $cat_post,
		'label' => __('Select Category to display Featured Post','vw-job-board'),
		'section' => 'vw_job_board_featured_job_section',
	));
	

	//Testimonial Section
	$wp_customize->add_section('vw_job_board_testimonial', array(
		'title'       => __('Testimonial Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_testimonial_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_testimonial_text',array(
		'description' => __('<p>1. More options for Testimonial section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for Testimonial section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_testimonial',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_testimonial_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_testimonial_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_testimonial',
		'type'=> 'hidden'
	));

	//Brand Partner Section
	$wp_customize->add_section('vw_job_board_brand_partner_sec', array(
		'title'       => __('Brand Partner Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_brand_partner_sec_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_brand_partner_sec_text',array(
		'description' => __('<p>1. More options for brand partner section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for brand partner section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_brand_partner_sec',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_brand_partner_sec_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_brand_partner_sec_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_brand_partner_sec',
		'type'=> 'hidden'
	));

	//Our Records Section
	$wp_customize->add_section('vw_job_board_our_records', array(
		'title'       => __('Our Records Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_our_records_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_our_records_text',array(
		'description' => __('<p>1. More options for our records section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for our records section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_our_records',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_our_records_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_our_records_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_our_records',
		'type'=> 'hidden'
	));

	//Latest News Section
	$wp_customize->add_section('vw_job_board_latest_news', array(
		'title'       => __('Latest News Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_latest_news_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_latest_news_text',array(
		'description' => __('<p>1. More options for latest news section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for latest news section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_latest_news',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_latest_news_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_latest_news_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_latest_news',
		'type'=> 'hidden'
	));

	//Download App Section
	$wp_customize->add_section('vw_job_board_download_app_sec', array(
		'title'       => __('Download App Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_download_app_sec_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_download_app_sec_text',array(
		'description' => __('<p>1. More options for download app section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for download app section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_download_app_sec',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_download_app_sec_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_download_app_sec_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_download_app_sec',
		'type'=> 'hidden'
	));

	//Pricing Plan Section
	$wp_customize->add_section('vw_job_board_pricing_plan', array(
		'title'       => __('Pricing Plan Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_pricing_plan_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_pricing_plan_text',array(
		'description' => __('<p>1. More options for pricing plan section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for pricing plan section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_pricing_plan',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_pricing_plan_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_pricing_plan_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_pricing_plan',
		'type'=> 'hidden'
	));

	//FAQ Section
	$wp_customize->add_section('vw_job_board_faq', array(
		'title'       => __('FAQ Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_faq_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_faq_text',array(
		'description' => __('<p>1. More options for faq section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for faq section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_faq',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_faq_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_faq_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_faq',
		'type'=> 'hidden'
	));

	//Registration Section
	$wp_customize->add_section('vw_job_board_registration', array(
		'title'       => __('Registration Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_registration_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_registration_text',array(
		'description' => __('<p>1. More options for registration section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for registration section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_registration',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_registration_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_registration_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_registration',
		'type'=> 'hidden'
	));

	//Newsletter Section
	$wp_customize->add_section('vw_job_board_newsletter', array(
		'title'       => __('Newsletter Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_newsletter_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_newsletter_text',array(
		'description' => __('<p>1. More options for newsletter section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for newsletter section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_newsletter',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_newsletter_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_newsletter_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_newsletter',
		'type'=> 'hidden'
	));

	//Newsletter Section
	$wp_customize->add_section('vw_job_board_newsletter', array(
		'title'       => __('Newsletter Section', 'vw-job-board'),
		'description' => __('<p class="premium-opt">Premium Theme Features</p>','vw-job-board'),
		'priority'    => null,
		'panel'       => 'vw_job_board_homepage_panel',
	));

	$wp_customize->add_setting('vw_job_board_newsletter_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_newsletter_text',array(
		'description' => __('<p>1. More options for newsletter section.</p>
			<p>2. Unlimited images options.</p>
			<p>3. Color options for newsletter section.</p>','vw-job-board'),
		'section'=> 'vw_job_board_newsletter',
		'type'=> 'hidden'
	));

	$wp_customize->add_setting('vw_job_board_newsletter_btn',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_newsletter_btn',array(
		'description' => "<a class='go-pro' target='_blank' href='https://www.vwthemes.com/products/job-portal-wordpress-theme'>More Info</a>",
		'section'=> 'vw_job_board_newsletter',
		'type'=> 'hidden'
	));

	//Footer Text
	$wp_customize->add_section('vw_job_board_footer',array(
		'title'	=> esc_html__('Footer Settings','vw-job-board'),
		'description' => __('For more options of the footer section </br> <a class="go-pro-btn" target="blank" href="https://www.vwthemes.com/products/job-portal-wordpress-theme">GO PRO</a>','vw-job-board'),
		'panel' => 'vw_job_board_homepage_panel',
	));	

	$wp_customize->add_setting( 'vw_job_board_footer_hide_show',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ));
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_footer_hide_show',array(
    'label' => esc_html__( 'Show / Hide Footer','vw-job-board' ),
    'section' => 'vw_job_board_footer'
  )));

 	// font size
	$wp_customize->add_setting('vw_job_board_button_footer_font_size',array(
		'default'=> 25,
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_button_footer_font_size',array(
		'label'	=> __('Footer Heading Font Size','vw-job-board'),
  		'type'        => 'number',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
		'section'=> 'vw_job_board_footer',
	));

	$wp_customize->add_setting('vw_job_board_button_footer_heading_letter_spacing',array(
		'default'=> 1,
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_button_footer_heading_letter_spacing',array(
		'label'	=> __('Heading Letter Spacing','vw-job-board'),
  		'type'        => 'number',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
	),
		'section'=> 'vw_job_board_footer',
	));

	// text trasform
	$wp_customize->add_setting('vw_job_board_button_footer_text_transform',array(
		'default'=> 'Capitalize',
		'sanitize_callback'	=> 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_button_footer_text_transform',array(
		'type' => 'radio',
		'label'	=> __('Heading Text Transform','vw-job-board'),
		'choices' => array(
      'Uppercase' => __('Uppercase','vw-job-board'),
      'Capitalize' => __('Capitalize','vw-job-board'),
      'Lowercase' => __('Lowercase','vw-job-board'),
    ),
		'section'=> 'vw_job_board_footer',
	));

	$wp_customize->add_setting('vw_job_board_footer_heading_weight',array(
        'default' => 600,
        'transport' => 'refresh',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_footer_heading_weight',array(
        'type' => 'select',
        'label' => __('Heading Font Weight','vw-job-board'),
        'section' => 'vw_job_board_footer',
        'choices' => array(
        	'100' => __('100','vw-job-board'),
            '200' => __('200','vw-job-board'),
            '300' => __('300','vw-job-board'),
            '400' => __('400','vw-job-board'),
            '500' => __('500','vw-job-board'),
            '600' => __('600','vw-job-board'),
            '700' => __('700','vw-job-board'),
            '800' => __('800','vw-job-board'),
            '900' => __('900','vw-job-board'),
        ),
	) );

  $wp_customize->add_setting('vw_job_board_footer_template',array(
    'default'	=> esc_html('vw_job_board-footer-one'),
    'sanitize_callback'	=> 'vw_job_board_sanitize_choices'
  ));
  $wp_customize->add_control('vw_job_board_footer_template',array(
    'label'	=> esc_html__('Footer style','vw-job-board'),
    'section'	=> 'vw_job_board_footer',
    'setting'	=> 'vw_job_board_footer_template',
    'type' => 'select',
    'choices' => array(
        'vw_job_board-footer-one' => esc_html__('Style 1', 'vw-job-board'),
        'vw_job_board-footer-two' => esc_html__('Style 2', 'vw-job-board'),
        'vw_job_board-footer-three' => esc_html__('Style 3', 'vw-job-board'),
        'vw_job_board-footer-four' => esc_html__('Style 4', 'vw-job-board'),
        'vw_job_board-footer-five' => esc_html__('Style 5', 'vw-job-board'),
    )
  ));

	$wp_customize->add_setting('vw_job_board_footer_background_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_footer_background_color', array(
		'label'    => __('Footer Background Color', 'vw-job-board'),
		'section'  => 'vw_job_board_footer',
	)));

	$wp_customize->add_setting('vw_job_board_footer_background_image',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw',
	));
	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize,'vw_job_board_footer_background_image',array(
        'label' => __('Footer Background Image','vw-job-board'),
        'section' => 'vw_job_board_footer'
	)));

	$wp_customize->add_setting('vw_job_board_footer_img_position',array(
	  'default' => 'center center',
	  'transport' => 'refresh',
	  'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_footer_img_position',array(
		'type' => 'select',
		'label' => __('Footer Image Position','vw-job-board'),
		'section' => 'vw_job_board_footer',
		'choices' 	=> array(
			'left top' 		=> esc_html__( 'Top Left', 'vw-job-board' ),
			'center top'   => esc_html__( 'Top', 'vw-job-board' ),
			'right top'   => esc_html__( 'Top Right', 'vw-job-board' ),
			'left center'   => esc_html__( 'Left', 'vw-job-board' ),
			'center center'   => esc_html__( 'Center', 'vw-job-board' ),
			'right center'   => esc_html__( 'Right', 'vw-job-board' ),
			'left bottom'   => esc_html__( 'Bottom Left', 'vw-job-board' ),
			'center bottom'   => esc_html__( 'Bottom', 'vw-job-board' ),
			'right bottom'   => esc_html__( 'Bottom Right', 'vw-job-board' ),
		),
	)); 

	// Footer
	$wp_customize->add_setting('vw_job_board_img_footer',array(
		'default'=> 'scroll',
		'sanitize_callback'	=> 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_img_footer',array(
		'type' => 'select',
		'label'	=> __('Footer Background Attatchment','vw-job-board'),
		'choices' => array(
            'fixed' => __('fixed','vw-job-board'),
            'scroll' => __('scroll','vw-job-board'),
        ),
		'section'=> 'vw_job_board_footer',
	));

	$wp_customize->add_setting('vw_job_board_footer_widgets_heading',array(
    'default' => 'Left',
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_footer_widgets_heading',array(
    'type' => 'select',
    'label' => __('Footer Widget Heading','vw-job-board'),
    'section' => 'vw_job_board_footer',
    'choices' => array(
    	'Left' => __('Left','vw-job-board'),
      'Center' => __('Center','vw-job-board'),
      'Right' => __('Right','vw-job-board')
    ),
	) );

	$wp_customize->add_setting('vw_job_board_footer_widgets_content',array(
    'default' => 'Left',
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_footer_widgets_content',array(
    'type' => 'select',
    'label' => __('Footer Widget Content','vw-job-board'),
    'section' => 'vw_job_board_footer',
    'choices' => array(
    	'Left' => __('Left','vw-job-board'),
      'Center' => __('Center','vw-job-board'),
      'Right' => __('Right','vw-job-board')
    ),
	) );

	// footer padding
	$wp_customize->add_setting('vw_job_board_footer_padding',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_footer_padding',array(
		'label'	=> __('Footer Top Bottom Padding','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
      'placeholder' => __( '10px', 'vw-job-board' ),
    ),
		'section'=> 'vw_job_board_footer',
		'type'=> 'text'
	));

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('vw_job_board_footer_text', array( 
		'selector' => '.copyright p', 
		'render_callback' => 'vw_job_board_Customize_partial_vw_job_board_footer_text', 
	));

	$wp_customize->add_setting( 'vw_job_board_copyright_hide_show',array(
      'default' => 1,
      'transport' => 'refresh',
      'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ));
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_copyright_hide_show',array(
      'label' => esc_html__( 'Show / Hide Copyright','vw-job-board' ),
      'section' => 'vw_job_board_footer'
    )));

	$wp_customize->add_setting('vw_job_board_copyright_background_color', array(
		'default'           => '#4A37F3',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_copyright_background_color', array(
		'label'    => __('Copyright Background Color', 'vw-job-board'),
		'section'  => 'vw_job_board_footer',
	)));
	
	$wp_customize->add_setting('vw_job_board_copyright_text_color', array(
		'default'           => '#fff',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_copyright_text_color', array(
		'label'    => __('Copyright Text Color', 'vw-job-board'),
		'section'  => 'vw_job_board_footer',
	)));

	$wp_customize->add_setting('vw_job_board_footer_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));	
	$wp_customize->add_control('vw_job_board_footer_text',array(
		'label'	=> esc_html__('Copyright Text','vw-job-board'),
		'input_attrs' => array(
    'placeholder' => esc_html__( 'Copyright 2021, .....', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_copyright_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_copyright_font_size',array(
		'label'	=> __('Copyright Font Size','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_footer',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_copyright_font_weight',array(
	  'default' => 400,
	  'transport' => 'refresh',
	  'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_copyright_font_weight',array(
	    'type' => 'select',
	    'label' => __('Copyright Font Weight','vw-job-board'),
	    'section' => 'vw_job_board_footer',
	    'choices' => array(
	    	'100' => __('100','vw-job-board'),
	        '200' => __('200','vw-job-board'),
	        '300' => __('300','vw-job-board'),
	        '400' => __('400','vw-job-board'),
	        '500' => __('500','vw-job-board'),
	        '600' => __('600','vw-job-board'),
	        '700' => __('700','vw-job-board'),
	        '800' => __('800','vw-job-board'),
	        '900' => __('900','vw-job-board'),
    ),
	));

	$wp_customize->add_setting('vw_job_board_copyright_alingment',array(
    'default' => 'center',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control(new VW_Job_Board_Image_Radio_Control($wp_customize, 'vw_job_board_copyright_alingment', array(
    'type' => 'select',
    'label' => esc_html__('Copyright Alignment','vw-job-board'),
    'section' => 'vw_job_board_footer',
    'settings' => 'vw_job_board_copyright_alingment',
    'choices' => array(
        'left' => esc_url(get_template_directory_uri()).'/assets/images/copyright1.png',
        'center' => esc_url(get_template_directory_uri()).'/assets/images/copyright2.png',
        'right' => esc_url(get_template_directory_uri()).'/assets/images/copyright3.png'
  ))));

  $wp_customize->add_setting( 'vw_job_board_hide_show_scroll',array(
  	'default' => 1,
    	'transport' => 'refresh',
    	'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ));  
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_hide_show_scroll',array(
    	'label' => esc_html__( 'Show / Hide Scroll to Top','vw-job-board' ),
    	'section' => 'vw_job_board_footer'
  )));

    //Selective Refresh
	$wp_customize->selective_refresh->add_partial('vw_job_board_scroll_to_top_icon', array( 
		'selector' => '.scrollup i', 
		'render_callback' => 'vw_job_board_Customize_partial_vw_job_board_scroll_to_top_icon', 
	));

    $wp_customize->add_setting('vw_job_board_scroll_top_alignment',array(
        'default' => 'Right',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control(new VW_Job_Board_Image_Radio_Control($wp_customize, 'vw_job_board_scroll_top_alignment', array(
        'type' => 'select',
        'label' => esc_html__('Scroll To Top','vw-job-board'),
        'section' => 'vw_job_board_footer',
        'settings' => 'vw_job_board_scroll_top_alignment',
        'choices' => array(
            'Left' => esc_url(get_template_directory_uri()).'/assets/images/layout1.png',
            'Center' => esc_url(get_template_directory_uri()).'/assets/images/layout2.png',
            'Right' => esc_url(get_template_directory_uri()).'/assets/images/layout3.png'
    ))));

	//Blog Post
	$wp_customize->add_panel( 'vw_job_board_blog_post_parent_panel', array(
		'title' => esc_html__( 'Blog Post Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_panel_id',
		'priority' => 20,
	));

	// Add example section and controls to the middle (second) panel
	$wp_customize->add_section( 'vw_job_board_post_settings', array(
		'title' => esc_html__( 'Post Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_blog_post_parent_panel',
	));

	//Blog Post Layout
  $wp_customize->add_setting('vw_job_board_blog_layout_option',array(
    'default' => 'Default',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
  ));
  $wp_customize->add_control(new VW_Job_Board_Image_Radio_Control($wp_customize, 'vw_job_board_blog_layout_option', array(
    'type' => 'select',
    'label' => __('Blog Post Layouts','vw-job-board'),
    'section' => 'vw_job_board_post_settings',
    'choices' => array(
        'Default' => esc_url(get_template_directory_uri()).'/assets/images/blog-layout1.png',
        'Center' => esc_url(get_template_directory_uri()).'/assets/images/blog-layout2.png',
        'Left' => esc_url(get_template_directory_uri()).'/assets/images/blog-layout3.png',
  ))));

	$wp_customize->add_setting('vw_job_board_theme_options',array(
    'default' => 'Right Sidebar',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_theme_options',array(
    'type' => 'select',
    'label' => esc_html__('Post Sidebar Layout','vw-job-board'),
    'description' => esc_html__('Here you can change the sidebar layout for posts. ','vw-job-board'),
    'section' => 'vw_job_board_post_settings',
    'choices' => array(
      'Left Sidebar' => esc_html__('Left Sidebar','vw-job-board'),
      'Right Sidebar' => esc_html__('Right Sidebar','vw-job-board'),
      'One Column' => esc_html__('One Column','vw-job-board'),
			'Three Columns' => __('Three Columns','vw-job-board'),
			'Four Columns' => __('Four Columns','vw-job-board'),
      'Grid Layout' => esc_html__('Grid Layout','vw-job-board')
    ),
	) );

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('vw_job_board_toggle_postdate', array( 
		'selector' => '.post-main-box h2 a', 
		'render_callback' => 'vw_job_board_Customize_partial_vw_job_board_toggle_postdate', 
	));

	$wp_customize->add_setting('vw_job_board_toggle_postdate_icon',array(
		'default'	=> 'fas fa-calendar-alt',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_toggle_postdate_icon',array(
		'label'	=> __('Add Post Date Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_post_settings',
		'setting'	=> 'vw_job_board_toggle_postdate_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'vw_job_board_toggle_postdate',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ) );
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_toggle_postdate',array(
      'label' => esc_html__( 'Show / Hide Post Date','vw-job-board' ),
      'section' => 'vw_job_board_post_settings'
  )));

   $wp_customize->add_setting('vw_job_board_toggle_author_icon',array(
		'default'	=> 'fas fa-user',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_toggle_author_icon',array(
		'label'	=> __('Add Author Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_post_settings',
		'setting'	=> 'vw_job_board_toggle_author_icon',
		'type'		=> 'icon'
	)));

  $wp_customize->add_setting( 'vw_job_board_toggle_author',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_toggle_author',array(
		'label' => esc_html__( 'Show / Hide Author','vw-job-board' ),
		'section' => 'vw_job_board_post_settings'
	)));

   $wp_customize->add_setting('vw_job_board_toggle_comments_icon',array(
		'default'	=> 'fa fa-comments',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_toggle_comments_icon',array(
		'label'	=> __('Add Comments Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_post_settings',
		'setting'	=> 'vw_job_board_toggle_comments_icon',
		'type'		=> 'icon'
	)));

    $wp_customize->add_setting( 'vw_job_board_toggle_comments',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ) );
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_toggle_comments',array(
		'label' => esc_html__( 'Show / Hide Comments','vw-job-board' ),
		'section' => 'vw_job_board_post_settings'
    )));


  $wp_customize->add_setting('vw_job_board_toggle_time_icon',array(
		'default'	=> 'fas fa-clock',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_toggle_time_icon',array(
		'label'	=> __('Add Time Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_post_settings',
		'setting'	=> 'vw_job_board_toggle_time_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'vw_job_board_toggle_time',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
	) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_toggle_time',array(
		'label' => esc_html__( 'Show / Hide Time','vw-job-board' ),
		'section' => 'vw_job_board_post_settings'
	)));

	$wp_customize->add_setting( 'vw_job_board_featured_image_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
	));
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_featured_image_hide_show', array(
	'label' => esc_html__( 'Show / Hide Featured Image','vw-job-board' ),
	'section' => 'vw_job_board_post_settings'
	)));

  $wp_customize->add_setting( 'vw_job_board_featured_image_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_featured_image_border_radius', array(
		'label'       => esc_html__( 'Featured Image Border Radius','vw-job-board' ),
		'section'     => 'vw_job_board_post_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting( 'vw_job_board_featured_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_featured_image_box_shadow', array(
		'label'       => esc_html__( 'Featured Image Box Shadow','vw-job-board' ),
		'section'     => 'vw_job_board_post_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	//Featured Image
	$wp_customize->add_setting('vw_job_board_blog_post_featured_image_dimension',array(
   'default' => 'default',
   'sanitize_callback'	=> 'vw_job_board_sanitize_choices'
	));
  $wp_customize->add_control('vw_job_board_blog_post_featured_image_dimension',array(
		'type' => 'select',
		'label'	=> __('Blog Post Featured Image Dimension','vw-job-board'),
		'section'	=> 'vw_job_board_post_settings',
		'choices' => array(
		'default' => __('Default','vw-job-board'),
		'custom' => __('Custom Image Size','vw-job-board'),
      ),
  ));

	$wp_customize->add_setting('vw_job_board_blog_post_featured_image_custom_width',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
		));
	$wp_customize->add_control('vw_job_board_blog_post_featured_image_custom_width',array(
		'label'	=> __('Featured Image Custom Width','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
    	'placeholder' => __( '10px', 'vw-job-board' ),),
		'section'=> 'vw_job_board_post_settings',
		'type'=> 'text',
		'active_callback' => 'vw_job_board_blog_post_featured_image_dimension'
		));

	$wp_customize->add_setting('vw_job_board_blog_post_featured_image_custom_height',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_blog_post_featured_image_custom_height',array(
		'label'	=> __('Featured Image Custom Height','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
    	'placeholder' => __( '10px', 'vw-job-board' ),),
		'section'=> 'vw_job_board_post_settings',
		'type'=> 'text',
		'active_callback' => 'vw_job_board_blog_post_featured_image_dimension'
	));

	$wp_customize->add_setting( 'vw_job_board_excerpt_number', array(
		'default'              => 30,
		'type'                 => 'theme_mod',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range',
		'sanitize_js_callback' => 'absint',
	) );
	$wp_customize->add_control( 'vw_job_board_excerpt_number', array(
		'label'       => esc_html__( 'Excerpt length','vw-job-board' ),
		'section'     => 'vw_job_board_post_settings',
		'type'        => 'range',
		'settings'    => 'vw_job_board_excerpt_number',
		'input_attrs' => array(
		'step'             => 5,
		'min'              => 0,
		'max'              => 50,
	),
	) );

	$wp_customize->add_setting('vw_job_board_meta_field_separator',array(
	'default'=> '|',
	'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_meta_field_separator',array(
	'label'	=> __('Add Meta Separator','vw-job-board'),
	'description' => __('Add the seperator for meta box. Example: "|", "/", etc.','vw-job-board'),
	'section'=> 'vw_job_board_post_settings',
	'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_excerpt_settings',array(
	  'default' => 'Excerpt',
	  'transport' => 'refresh',
	  'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_excerpt_settings',array(
	  'type' => 'select',
	  'label' => esc_html__('Post Content','vw-job-board'),
	  'section' => 'vw_job_board_post_settings',
	  'choices' => array(
	  	'Content' => esc_html__('Content','vw-job-board'),
	      'Excerpt' => esc_html__('Excerpt','vw-job-board'),
	      'No Content' => esc_html__('No Content','vw-job-board')
	  ),
	) );

	$wp_customize->add_setting('vw_job_board_blog_excerpt_suffix',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_blog_excerpt_suffix',array(
		'label'	=> __('Add Excerpt Suffix','vw-job-board'),
		'input_attrs' => array(
    	'placeholder' => __( '[...]', 'vw-job-board' ),
      ),
		'section'=> 'vw_job_board_post_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting( 'vw_job_board_blog_pagination_hide_show',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ));
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_blog_pagination_hide_show',array(
    'label' => esc_html__( 'Show / Hide Blog Pagination','vw-job-board' ),
    'section' => 'vw_job_board_post_settings'
  )));

	$wp_customize->add_setting( 'vw_job_board_blog_pagination_type', array(
	  'default'			=> 'blog-page-numbers',
	  'sanitize_callback'	=> 'vw_job_board_sanitize_choices'
  ));
  $wp_customize->add_control( 'vw_job_board_blog_pagination_type', array(
	  'section' => 'vw_job_board_post_settings',
	  'type' => 'select',
	  'label' => __( 'Blog Pagination', 'vw-job-board' ),
	  'choices'		=> array(
	      'blog-page-numbers'  => __( 'Numeric', 'vw-job-board' ),
	      'next-prev' => __( 'Older Posts/Newer Posts', 'vw-job-board' ),
  )));

  $wp_customize->add_setting('vw_job_board_blog_page_posts_settings',array(
    'default' => 'Into Blocks',
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_blog_page_posts_settings',array(
    'type' => 'select',
    'label' => __('Display Blog Posts','vw-job-board'),
    'section' => 'vw_job_board_post_settings',
    'choices' => array(
    	'Into Blocks' => __('Into Blocks','vw-job-board'),
        'Without Blocks' => __('Without Blocks','vw-job-board')
      ),
	) );

  // Button Settings
	$wp_customize->add_section( 'vw_job_board_button_settings', array(
		'title' => esc_html__( 'Button Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_blog_post_parent_panel',
	));

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('vw_job_board_button_text', array( 
		'selector' => '.post-main-box .more-btn a', 
		'render_callback' => 'vw_job_board_Customize_partial_vw_job_board_button_text', 
	));

  $wp_customize->add_setting('vw_job_board_button_text',array(
		'default'=> esc_html__('Read More','vw-job-board'),
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_button_text',array(
		'label'	=> esc_html__('Add Button Text','vw-job-board'),
		'input_attrs' => array(
    'placeholder' => esc_html__( 'Read More', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_button_settings',
		'type'=> 'text'
	));

	// font size button
	$wp_customize->add_setting('vw_job_board_button_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_button_font_size',array(
		'label'	=> __('Button Font Size','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
      'placeholder' => __( '10px', 'vw-job-board' ),
    ),
    'type'        => 'text',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
		'section'=> 'vw_job_board_button_settings',
	));

	$wp_customize->add_setting( 'vw_job_board_button_border_radius', array(
		'default'              => 10,
		'type'                 => 'theme_mod',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range',
		'sanitize_js_callback' => 'absint',
	) );
	$wp_customize->add_control( 'vw_job_board_button_border_radius', array(
		'label'       => esc_html__( 'Button Border Radius','vw-job-board' ),
		'section'     => 'vw_job_board_button_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting('vw_job_board_button_padding_top_bottom',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_button_padding_top_bottom',array(
		'label'	=> esc_html__('Padding Top Bottom','vw-job-board'),
		'description' => esc_html__('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( '10px', 'vw-job-board' ),
        ),
		'section' => 'vw_job_board_button_settings',
		'type' => 'text'
	));

	$wp_customize->add_setting('vw_job_board_button_padding_left_right',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_button_padding_left_right',array(
		'label'	=> esc_html__('Padding Left Right','vw-job-board'),
		'description' => esc_html__('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( '10px', 'vw-job-board' ),
        ),
		'section' => 'vw_job_board_button_settings',
		'type' => 'text'
	));

	$wp_customize->add_setting('vw_job_board_button_letter_spacing',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_button_letter_spacing',array(
		'label'	=> __('Button Letter Spacing','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
      	'placeholder' => __( '10px', 'vw-job-board' ),
    ),
    	'type'        => 'text',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
		'section'=> 'vw_job_board_button_settings',
	));

	// text trasform
	$wp_customize->add_setting('vw_job_board_button_text_transform',array(
		'default'=> 'Uppercase',
		'sanitize_callback'	=> 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_button_text_transform',array(
		'type' => 'radio',
		'label'	=> __('Button Text Transform','vw-job-board'),
		'choices' => array(
            'Uppercase' => __('Uppercase','vw-job-board'),
            'Capitalize' => __('Capitalize','vw-job-board'),
            'Lowercase' => __('Lowercase','vw-job-board'),
        ),
		'section'=> 'vw_job_board_button_settings',
	));

	// Related Post Settings
	$wp_customize->add_section( 'vw_job_board_related_posts_settings', array(
		'title' => esc_html__( 'Related Posts Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_blog_post_parent_panel',
	));

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial('vw_job_board_related_post_title', array( 
		'selector' => '.related-post h3', 
		'render_callback' => 'vw_job_board_Customize_partial_vw_job_board_related_post_title', 
	));

    $wp_customize->add_setting( 'vw_job_board_related_post',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ) );
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_related_post',array(
		'label' => esc_html__( 'Show / Hide Related Post','vw-job-board' ),
		'section' => 'vw_job_board_related_posts_settings'
    )));

    $wp_customize->add_setting('vw_job_board_related_post_title',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_related_post_title',array(
		'label'	=> esc_html__('Add Related Post Title','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'Related Post', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_related_posts_settings',
		'type'=> 'text'
	));

   	$wp_customize->add_setting('vw_job_board_related_posts_count',array(
		'default'=> 3,
		'sanitize_callback'	=> 'vw_job_board_sanitize_number_absint'
	));
	$wp_customize->add_control('vw_job_board_related_posts_count',array(
		'label'	=> esc_html__('Add Related Post Count','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( '3', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_related_posts_settings',
		'type'=> 'number'
	));

	$wp_customize->add_setting( 'vw_job_board_related_posts_excerpt_number', array(
		'default'              => 20,
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_related_posts_excerpt_number', array(
		'label'       => esc_html__( 'Related Posts Excerpt length','vw-job-board' ),
		'section'     => 'vw_job_board_related_posts_settings',
		'type'        => 'range',
		'settings'    => 'vw_job_board_related_posts_excerpt_number',
		'input_attrs' => array(
			'step'             => 5,
			'min'              => 0,
			'max'              => 50,
		),
	) );

  // Single Post Settings
	$wp_customize->add_section( 'vw_job_board_single_blog_settings', array(
		'title' => __( 'Single Post Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_blog_post_parent_panel',
	));

	$wp_customize->add_setting('vw_job_board_single_postdate_icon',array(
		'default'	=> 'fas fa-calendar-alt',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_single_postdate_icon',array(
		'label'	=> __('Add Post Date Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_single_blog_settings',
		'setting'	=> 'vw_job_board_single_postdate_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'vw_job_board_single_postdate',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'vw_job_board_switch_sanitization'
	) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_postdate',array(
	    'label' => esc_html__( 'Show / Hide Date','vw-job-board' ),
	   'section' => 'vw_job_board_single_blog_settings'
	)));

	$wp_customize->add_setting('vw_job_board_single_author_icon',array(
		'default'	=> 'fas fa-user',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_single_author_icon',array(
		'label'	=> __('Add Author Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_single_blog_settings',
		'setting'	=> 'vw_job_board_single_author_icon',
		'type'		=> 'icon'
	)));

  $wp_customize->add_setting( 'vw_job_board_single_author',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
	) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_author',array(
	    'label' => esc_html__( 'Show / Hide Author','vw-job-board' ),
	    'section' => 'vw_job_board_single_blog_settings'
	)));

  $wp_customize->add_setting('vw_job_board_single_comments_icon',array(
		'default'	=> 'fa fa-comments',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_single_comments_icon',array(
		'label'	=> __('Add Comments Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_single_blog_settings',
		'setting'	=> 'vw_job_board_single_comments_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'vw_job_board_single_comments',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'vw_job_board_switch_sanitization'
	) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_comments',array(
	    'label' => esc_html__( 'Show / Hide Comments','vw-job-board' ),
	    'section' => 'vw_job_board_single_blog_settings'
	)));

  $wp_customize->add_setting('vw_job_board_single_time_icon',array(
		'default'	=> 'fas fa-clock',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_single_time_icon',array(
		'label'	=> __('Add Time Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_single_blog_settings',
		'setting'	=> 'vw_job_board_single_time_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'vw_job_board_single_time',array(
	    'default' => 1,
	    'transport' => 'refresh',
	    'sanitize_callback' => 'vw_job_board_switch_sanitization'
	) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_time',array(
	    'label' => esc_html__( 'Show / Hide Time','vw-job-board' ),
	    'section' => 'vw_job_board_single_blog_settings'
	)));

	$wp_customize->add_setting( 'vw_job_board_single_post_breadcrumb',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ) );
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_post_breadcrumb',array(
		'label' => esc_html__( 'Show / Hide Breadcrumb','vw-job-board' ),
		'section' => 'vw_job_board_single_blog_settings'
  )));

  // Single Posts Category
	$wp_customize->add_setting( 'vw_job_board_single_post_category',array(
	'default' => true,
	'transport' => 'refresh',
	'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ) );
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_post_category',array(
	'label' => esc_html__( 'Show / Hide Category','vw-job-board' ),
	'section' => 'vw_job_board_single_blog_settings'
  )));

	$wp_customize->add_setting( 'vw_job_board_toggle_tags',array(
		'default' => 0,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
	));
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_toggle_tags', array(
		'label' => esc_html__( 'Show / Hide Tags','vw-job-board' ),
		'section' => 'vw_job_board_single_blog_settings'
  )));

  $wp_customize->add_setting( 'vw_job_board_single_blog_post_navigation_show_hide',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ));
	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_blog_post_navigation_show_hide', array(
	  'label' => esc_html__( 'Show / Hide Post Navigation','vw-job-board' ),
	  'section' => 'vw_job_board_single_blog_settings'
  )));

	//navigation text
	$wp_customize->add_setting('vw_job_board_single_blog_prev_navigation_text',array(
		'default'=> 'PREVIOUS',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_single_blog_prev_navigation_text',array(
		'label'	=> __('Post Navigation Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'PREVIOUS', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_single_blog_next_navigation_text',array(
		'default'=> 'NEXT',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_single_blog_next_navigation_text',array(
		'label'	=> __('Post Navigation Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'NEXT', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_single_blog_comment_title',array(
		'default'=> 'Leave a Reply',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('vw_job_board_single_blog_comment_title',array(
		'label'	=> __('Add Comment Title','vw-job-board'),
		'input_attrs' => array(
        'placeholder' => __( 'Leave a Reply', 'vw-job-board' ),
    	),
		'section'=> 'vw_job_board_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_single_blog_comment_button_text',array(
		'default'=> 'Post Comment',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('vw_job_board_single_blog_comment_button_text',array(
		'label'	=> __('Add Comment Button Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'Post Comment', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_single_blog_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting( 'vw_job_board_singlepost_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_singlepost_image_box_shadow', array(
		'label'       => esc_html__( 'Single post Image Box Shadow','vw-job-board' ),
		'section'     => 'vw_job_board_single_blog_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

  $wp_customize->add_setting('vw_job_board_meta_field_singleseparator',array(
    'default'=> '|',
    'sanitize_callback' => 'sanitize_text_field'
  ));
  $wp_customize->add_control('vw_job_board_meta_field_singleseparator',array(
    'label' => __('Add Meta Separator','vw-job-board'),
    'description' => __('Add the seperator for meta box. Example: "", "/", etc.','vw-job-board'),
    'section'=> 'vw_job_board_single_blog_settings',
    'type'=> 'text'
  ));

  // Grid layout setting
	$wp_customize->add_section( 'vw_job_board_grid_layout_settings', array(
		'title' => __( 'Grid Layout Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_blog_post_parent_panel',
	));

  $wp_customize->add_setting('vw_job_board_grid_postdate_icon',array(
		'default'	=> 'fas fa-calendar-alt',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
    $wp_customize,'vw_job_board_grid_postdate_icon',array(
		'label'	=> __('Add Post Date Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_grid_layout_settings',
		'setting'	=> 'vw_job_board_grid_postdate_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting( 'vw_job_board_grid_postdate',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ) );
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_grid_postdate',array(
      'label' => esc_html__( 'Show / Hide Post Date','vw-job-board' ),
      'section' => 'vw_job_board_grid_layout_settings'
  )));

	$wp_customize->add_setting('vw_job_board_grid_author_icon',array(
		'default'	=> 'fas fa-user',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_grid_author_icon',array(
		'label'	=> __('Add Author Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_grid_layout_settings',
		'setting'	=> 'vw_job_board_grid_author_icon',
		'type'		=> 'icon'
	)));

  $wp_customize->add_setting( 'vw_job_board_grid_author',array(
			'default' => 1,
			'transport' => 'refresh',
			'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ) );
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_grid_author',array(
			'label' => esc_html__( 'Show / Hide Author','vw-job-board' ),
			'section' => 'vw_job_board_grid_layout_settings'
  )));

  $wp_customize->add_setting('vw_job_board_grid_comments_icon',array(
		'default'	=> 'fa fa-comments',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_grid_comments_icon',array(
		'label'	=> __('Add Comments Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_grid_layout_settings',
		'setting'	=> 'vw_job_board_grid_comments_icon',
		'type'		=> 'icon'
	)));

  $wp_customize->add_setting( 'vw_job_board_grid_comments',array(
			'default' => 1,
			'transport' => 'refresh',
			'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ) );
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_grid_comments',array(
			'label' => esc_html__( 'Show / Hide Comments','vw-job-board' ),
			'section' => 'vw_job_board_grid_layout_settings'
  )));

  $wp_customize->add_setting( 'vw_job_board_grid_image_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
	));
  	$wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_grid_image_hide_show', array(
		'label' => esc_html__( 'Show / Hide Featured Image','vw-job-board' ),
		'section' => 'vw_job_board_grid_layout_settings'
  	)));

	$wp_customize->add_setting('vw_job_board_grid_post_meta_field_separator',array(
		'default'=> '|',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_grid_post_meta_field_separator',array(
		'label'	=> __('Add Meta Separator','vw-job-board'),
		'description' => __('Add the seperator for meta box. Example: "|", "/", etc.','vw-job-board'),
		'section'=> 'vw_job_board_grid_layout_settings',
		'type'=> 'text'
	));

	 $wp_customize->add_setting( 'vw_job_board_grid_excerpt_number', array(
		'default'              => 30,
		'type'                 => 'theme_mod',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range',
		'sanitize_js_callback' => 'absint',
	) );
	$wp_customize->add_control( 'vw_job_board_grid_excerpt_number', array(
		'label'       => esc_html__( 'Excerpt length','vw-job-board' ),
		'section'     => 'vw_job_board_grid_layout_settings',
		'type'        => 'range',
		'settings'    => 'vw_job_board_grid_excerpt_number',
		'input_attrs' => array(
			'step'             => 5,
			'min'              => 0,
			'max'              => 50,
		),
	) );

  $wp_customize->add_setting('vw_job_board_display_grid_posts_settings',array(
    'default' => 'Into Blocks',
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_display_grid_posts_settings',array(
    'type' => 'select',
    'label' => __('Display Grid Posts','vw-job-board'),
    'section' => 'vw_job_board_grid_layout_settings',
    'choices' => array(
    	'Into Blocks' => __('Into Blocks','vw-job-board'),
        'Without Blocks' => __('Without Blocks','vw-job-board')
    ),
	) );

  	$wp_customize->add_setting('vw_job_board_grid_button_text',array(
		'default'=> esc_html__('Read More','vw-job-board'),
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_grid_button_text',array(
		'label'	=> esc_html__('Add Button Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => esc_html__( 'Read More', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_grid_layout_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_grid_excerpt_suffix',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_grid_excerpt_suffix',array(
		'label'	=> __('Add Excerpt Suffix','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '[...]', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_grid_layout_settings',
		'type'=> 'text'
	));

    $wp_customize->add_setting('vw_job_board_grid_excerpt_settings',array(
        'default' => 'Excerpt',
        'transport' => 'refresh',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_grid_excerpt_settings',array(
        'type' => 'select',
        'label' => esc_html__('Grid Post Content','vw-job-board'),
        'section' => 'vw_job_board_grid_layout_settings',
        'choices' => array(
        	'Content' => esc_html__('Content','vw-job-board'),
            'Excerpt' => esc_html__('Excerpt','vw-job-board'),
            'No Content' => esc_html__('No Content','vw-job-board')
        ),
	) );

    $wp_customize->add_setting( 'vw_job_board_grid_featured_image_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_grid_featured_image_border_radius', array(
		'label'       => esc_html__( 'Grid Featured Image Border Radius','vw-job-board' ),
		'section'     => 'vw_job_board_grid_layout_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting( 'vw_job_board_grid_featured_image_box_shadow', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_grid_featured_image_box_shadow', array(
		'label'       => esc_html__( 'Grid Featured Image Box Shadow','vw-job-board' ),
		'section'     => 'vw_job_board_grid_layout_settings',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	//Others Settings
	$wp_customize->add_panel( 'vw_job_board_others_panel', array(
		'title' => esc_html__( 'Others Settings', 'vw-job-board' ),
		'panel' => 'vw_job_board_panel_id',
		'priority' => 20,
	));

	// Layout
	$wp_customize->add_section( 'vw_job_board_left_right', array(
  	'title' => esc_html__('General Settings', 'vw-job-board'),
		'panel' => 'vw_job_board_others_panel'
	) );

	$wp_customize->add_setting('vw_job_board_width_option',array(
    'default' => 'Wide Width',
    'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control(new VW_Job_Board_Image_Radio_Control($wp_customize, 'vw_job_board_width_option', array(
    'type' => 'select',
    'label' => esc_html__('Width Layouts','vw-job-board'),
    'description' => esc_html__('Here you can change the width layout of Website.','vw-job-board'),
    'section' => 'vw_job_board_left_right',
    'choices' => array(
      'Full Width' => esc_url(get_template_directory_uri()).'/assets/images/full-width.png',
      'Wide Width' => esc_url(get_template_directory_uri()).'/assets/images/wide-width.png',
      'Boxed' => esc_url(get_template_directory_uri()).'/assets/images/boxed-width.png',
    ))));

	$wp_customize->add_setting('vw_job_board_page_layout',array(
  'default' => 'One_Column',
  'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_page_layout',array(
    'type' => 'select',
    'label' => esc_html__('Page Sidebar Layout','vw-job-board'),
    'description' => esc_html__('Here you can change the sidebar layout for pages. ','vw-job-board'),
    'section' => 'vw_job_board_left_right',
    'choices' => array(
      'Left_Sidebar' => esc_html__('Left Sidebar','vw-job-board'),
      'Right_Sidebar' => esc_html__('Right Sidebar','vw-job-board'),
      'One_Column' => esc_html__('One Column','vw-job-board')
    ),
	) );

  $wp_customize->add_setting( 'vw_job_board_single_page_breadcrumb',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ) );
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_single_page_breadcrumb',array(
		'label' => esc_html__( 'Show / Hide Page Breadcrumb','vw-job-board' ),
		'section' => 'vw_job_board_left_right'
  )));

  //Wow Animation
	$wp_customize->add_setting( 'vw_job_board_animation',array(
    'default' => 1,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
  ));
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_animation',array(
    'label' => esc_html__( 'Show / Hide Animations','vw-job-board' ),
    'description' => __('Here you can disable overall site animation effect','vw-job-board'),
    'section' => 'vw_job_board_left_right'
  )));

    // Pre-Loader
	$wp_customize->add_setting( 'vw_job_board_loader_enable',array(
    'default' => false,
    'transport' => 'refresh',
    'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ) );
  $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_loader_enable',array(
      'label' => esc_html__( 'Show / Hide Pre-Loader','vw-job-board' ),
      'section' => 'vw_job_board_left_right'
  )));

	$wp_customize->add_setting('vw_job_board_preloader_bg_color', array(
		'default'           => '#4A37F3',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_preloader_bg_color', array(
		'label'    => __('Pre-Loader Background Color', 'vw-job-board'),
		'section'  => 'vw_job_board_left_right',
	)));

	$wp_customize->add_setting('vw_job_board_preloader_border_color', array(
		'default'           => '#ffffff',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_preloader_border_color', array(
		'label'    => __('Pre-Loader Border Color', 'vw-job-board'),
		'section'  => 'vw_job_board_left_right',
	)));

	$wp_customize->add_setting('vw_job_board_preloader_bg_img',array(
		'default'	=> '',
		'sanitize_callback'	=> 'esc_url_raw',
	));
	$wp_customize->add_control( new WP_Customize_Image_Control($wp_customize,'vw_job_board_preloader_bg_img',array(
    'label' => __('Preloader Background Image','vw-job-board'),
    'section' => 'vw_job_board_left_right'
	)));

	$wp_customize->add_setting('vw_job_board_bradcrumbs_alignment',array(
        'default' => 'Left',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_bradcrumbs_alignment',array(
        'type' => 'select',
        'label' => __('Bradcrumbs Alignment','vw-job-board'),
        'section' => 'vw_job_board_left_right',
        'choices' => array(
            'Left' => __('Left','vw-job-board'),
            'Right' => __('Right','vw-job-board'),
            'Center' => __('Center','vw-job-board'),
        ),
	) );

  //404 Page Setting
	$wp_customize->add_section('vw_job_board_404_page',array(
		'title'	=> __('404 Page Settings','vw-job-board'),
		'panel' => 'vw_job_board_others_panel',
	));

	$wp_customize->add_setting('vw_job_board_404_page_title',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('vw_job_board_404_page_title',array(
		'label'	=> __('Add Title','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '404 Not Found', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_404_page',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_404_page_content',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('vw_job_board_404_page_content',array(
		'label'	=> __('Add Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'Looks like you have taken a wrong turn, Dont worry, it happens to the best of us.', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_404_page',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_404_page_button_text',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_404_page_button_text',array(
		'label'	=> __('Add Button Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'GO BACK', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_404_page',
		'type'=> 'text'
	));

	//No Result Page Setting
	$wp_customize->add_section('vw_job_board_no_results_page',array(
		'title'	=> __('No Results Page Settings','vw-job-board'),
		'panel' => 'vw_job_board_others_panel',
	));

	$wp_customize->add_setting('vw_job_board_no_results_page_title',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('vw_job_board_no_results_page_title',array(
		'label'	=> __('Add Title','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'Nothing Found', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_no_results_page',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_no_results_page_content',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));

	$wp_customize->add_control('vw_job_board_no_results_page_content',array(
		'label'	=> __('Add Text','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_no_results_page',
		'type'=> 'text'
	));

	//Social Icon Setting
	$wp_customize->add_section('vw_job_board_social_icon_settings',array(
		'title'	=> __('Social Icons Settings','vw-job-board'),
		'panel' => 'vw_job_board_others_panel',
	));

	$wp_customize->add_setting('vw_job_board_social_icon_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_social_icon_font_size',array(
		'label'	=> __('Icon Font Size','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_social_icon_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_social_icon_padding',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_social_icon_padding',array(
		'label'	=> __('Icon Padding','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_social_icon_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_social_icon_width',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_social_icon_width',array(
		'label'	=> __('Icon Width','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_social_icon_settings',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_social_icon_height',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_social_icon_height',array(
		'label'	=> __('Icon Height','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_social_icon_settings',
		'type'=> 'text'
	));

	//Responsive Media Settings
	$wp_customize->add_section('vw_job_board_responsive_media',array(
		'title'	=> esc_html__('Responsive Media','vw-job-board'),
		'panel' => 'vw_job_board_others_panel',
	));

	$wp_customize->add_setting( 'vw_job_board_resp_topbar_hide_show',array(
      'default' => 0,
      'transport' => 'refresh',
      'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ));  
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_resp_topbar_hide_show',array(
      'label' => esc_html__( 'Show / Hide Topbar','vw-job-board' ),
      'section' => 'vw_job_board_responsive_media'
    )));

    $wp_customize->add_setting( 'vw_job_board_resp_slider_hide_show',array(
      	'default' => 0,
     	'transport' => 'refresh',
      	'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ));  
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_resp_slider_hide_show',array(
      	'label' => esc_html__( 'Show / Hide Slider','vw-job-board' ),
      	'section' => 'vw_job_board_responsive_media'
    )));

    $wp_customize->add_setting( 'vw_job_board_sidebar_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ));  
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_sidebar_hide_show',array(
      	'label' => esc_html__( 'Show / Hide Sidebar','vw-job-board' ),
      	'section' => 'vw_job_board_responsive_media'
    )));

    $wp_customize->add_setting( 'vw_job_board_responsive_preloader_hide',array(
        'default' => false,
        'transport' => 'refresh',
        'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ) );
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_responsive_preloader_hide',array(
        'label' => esc_html__( 'Show / Hide Preloader','vw-job-board' ),
        'section' => 'vw_job_board_responsive_media'
    )));

    $wp_customize->add_setting( 'vw_job_board_resp_scroll_top_hide_show',array(
		'default' => 1,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ));  
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_resp_scroll_top_hide_show',array(
      	'label' => esc_html__( 'Show / Hide Scroll To Top','vw-job-board' ),
      	'section' => 'vw_job_board_responsive_media'
    )));

    $wp_customize->add_setting('vw_job_board_resp_menu_toggle_btn_bg_color', array(
		'default'           => '',
		'sanitize_callback' => 'sanitize_hex_color',
	));
	$wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'vw_job_board_resp_menu_toggle_btn_bg_color', array(
		'label'    => __('Toggle Button Bg Color', 'vw-job-board'),
		'section'  => 'vw_job_board_responsive_media',
	)));

  $wp_customize->add_setting('vw_job_board_res_open_menu_icon',array(
		'default'	=> 'fas fa-bars',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_res_open_menu_icon',array(
		'label'	=> __('Add Open Menu Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_responsive_media',
		'setting'	=> 'vw_job_board_res_open_menu_icon',
		'type'		=> 'icon'
	)));

	$wp_customize->add_setting('vw_job_board_res_close_menu_icon',array(
		'default'	=> 'fas fa-times',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control(new VW_Job_Board_Fontawesome_Icon_Chooser(
        $wp_customize,'vw_job_board_res_close_menu_icon',array(
		'label'	=> __('Add Close Menu Icon','vw-job-board'),
		'transport' => 'refresh',
		'section'	=> 'vw_job_board_responsive_media',
		'setting'	=> 'vw_job_board_res_close_menu_icon',
		'type'		=> 'icon'
	)));
	
  //Woocommerce settings
	$wp_customize->add_section('vw_job_board_woocommerce_section', array(
		'title'    => __('WooCommerce Layout', 'vw-job-board'),
		'priority' => null,
		'panel'    => 'woocommerce',
	));

	//Selective Refresh
	$wp_customize->selective_refresh->add_partial( 'vw_job_board_woocommerce_shop_page_sidebar', array( 'selector' => '.post-type-archive-product #sidebar',
		'render_callback' => 'vw_job_board_customize_partial_vw_job_board_woocommerce_shop_page_sidebar', ) );

    //Woocommerce Shop Page Sidebar
	$wp_customize->add_setting( 'vw_job_board_woocommerce_shop_page_sidebar',array(
		'default' => 0,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ) );
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_woocommerce_shop_page_sidebar',array(
		'label' => esc_html__( 'Show / Hide Shop Page Sidebar','vw-job-board' ),
		'section' => 'vw_job_board_woocommerce_section'
    )));

   $wp_customize->add_setting('vw_job_board_shop_page_layout',array(
        'default' => 'Right Sidebar',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_shop_page_layout',array(
        'type' => 'select',
        'label' => __('Shop Page Sidebar Layout','vw-job-board'),
        'section' => 'vw_job_board_woocommerce_section',
        'choices' => array(
            'Left Sidebar' => __('Left Sidebar','vw-job-board'),
            'Right Sidebar' => __('Right Sidebar','vw-job-board'),
        ),
	) );

   //Selective Refresh
	$wp_customize->selective_refresh->add_partial( 'vw_job_board_woocommerce_single_product_page_sidebar', array( 'selector' => '.single-product #sidebar',
		'render_callback' => 'vw_job_board_customize_partial_vw_job_board_woocommerce_single_product_page_sidebar', ) );

    //Woocommerce Single Product page Sidebar
	$wp_customize->add_setting( 'vw_job_board_woocommerce_single_product_page_sidebar',array(
		'default' => 0,
		'transport' => 'refresh',
		'sanitize_callback' => 'vw_job_board_switch_sanitization'
   ) );
   $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_woocommerce_single_product_page_sidebar',array(
		'label' => esc_html__( 'Show / Hide Single Product Sidebar','vw-job-board' ),
		'section' => 'vw_job_board_woocommerce_section'
    )));

   $wp_customize->add_setting('vw_job_board_single_product_layout',array(
        'default' => 'Right Sidebar',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_single_product_layout',array(
        'type' => 'select',
        'label' => __('Single Product Sidebar Layout','vw-job-board'),
        'section' => 'vw_job_board_woocommerce_section',
        'choices' => array(
            'Left Sidebar' => __('Left Sidebar','vw-job-board'),
            'Right Sidebar' => __('Right Sidebar','vw-job-board'),
        ),
	) );

	//Products padding
	$wp_customize->add_setting('vw_job_board_products_padding_top_bottom',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_products_padding_top_bottom',array(
		'label'	=> __('Products Padding Top Bottom','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_products_padding_left_right',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_products_padding_left_right',array(
		'label'	=> __('Products Padding Left Right','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_woocommerce_section',
		'type'=> 'text'
	));

	//Products box shadow
	$wp_customize->add_setting( 'vw_job_board_products_box_shadow', array(
		'default'              => '',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_products_box_shadow', array(
		'label'       => esc_html__( 'Products Box Shadow','vw-job-board' ),
		'section'     => 'vw_job_board_woocommerce_section',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	//Products border radius
    $wp_customize->add_setting( 'vw_job_board_products_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_products_border_radius', array(
		'label'       => esc_html__( 'Products Border Radius','vw-job-board' ),
		'section'     => 'vw_job_board_woocommerce_section',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting( 'vw_job_board_products_button_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_products_button_border_radius', array(
		'label'       => esc_html__( 'Products Button Border Radius','vw-job-board' ),
		'section'     => 'vw_job_board_woocommerce_section',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

	$wp_customize->add_setting('vw_job_board_products_btn_padding_top_bottom',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_products_btn_padding_top_bottom',array(
		'label'	=> __('Products Button Padding Top Bottom','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_products_btn_padding_left_right',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_products_btn_padding_left_right',array(
		'label'	=> __('Products Button Padding Left Right','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_woocommerce_sale_font_size',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_woocommerce_sale_font_size',array(
		'label'	=> __('Sale Font Size','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_woocommerce_section',
		'type'=> 'text'
	));

	//Products Sale Badge
	$wp_customize->add_setting('vw_job_board_woocommerce_sale_position',array(
        'default' => 'right',
        'sanitize_callback' => 'vw_job_board_sanitize_choices'
	));
	$wp_customize->add_control('vw_job_board_woocommerce_sale_position',array(
        'type' => 'select',
        'label' => __('Sale Badge Position','vw-job-board'),
        'section' => 'vw_job_board_woocommerce_section',
        'choices' => array(
            'left' => __('Left','vw-job-board'),
            'right' => __('Right','vw-job-board'),
        ),
	) );

	$wp_customize->add_setting('vw_job_board_woocommerce_sale_padding_top_bottom',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_woocommerce_sale_padding_top_bottom',array(
		'label'	=> __('Sale Padding Top Bottom','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting('vw_job_board_woocommerce_sale_padding_left_right',array(
		'default'=> '',
		'sanitize_callback'	=> 'sanitize_text_field'
	));
	$wp_customize->add_control('vw_job_board_woocommerce_sale_padding_left_right',array(
		'label'	=> __('Sale Padding Left Right','vw-job-board'),
		'description'	=> __('Enter a value in pixels. Example:20px','vw-job-board'),
		'input_attrs' => array(
            'placeholder' => __( '10px', 'vw-job-board' ),
        ),
		'section'=> 'vw_job_board_woocommerce_section',
		'type'=> 'text'
	));

	$wp_customize->add_setting( 'vw_job_board_woocommerce_sale_border_radius', array(
		'default'              => '0',
		'transport' 		   => 'refresh',
		'sanitize_callback'    => 'vw_job_board_sanitize_number_range'
	) );
	$wp_customize->add_control( 'vw_job_board_woocommerce_sale_border_radius', array(
		'label'       => esc_html__( 'Sale Border Radius','vw-job-board' ),
		'section'     => 'vw_job_board_woocommerce_section',
		'type'        => 'range',
		'input_attrs' => array(
			'step'             => 1,
			'min'              => 1,
			'max'              => 50,
		),
	) );

  	// Related Product
    $wp_customize->add_setting( 'vw_job_board_related_product_show_hide',array(
        'default' => 1,
        'transport' => 'refresh',
        'sanitize_callback' => 'vw_job_board_switch_sanitization'
    ) );
    $wp_customize->add_control( new VW_Job_Board_Toggle_Switch_Custom_Control( $wp_customize, 'vw_job_board_related_product_show_hide',array(
        'label' => esc_html__( 'Show / Hide Related product','vw-job-board' ),
        'section' => 'vw_job_board_woocommerce_section'
    )));
	
}

add_action( 'customize_register', 'vw_job_board_customize_register' );

load_template( trailingslashit( get_template_directory() ) . '/inc/logo/logo-resizer.php' );

/**
 * Singleton class for handling the theme's customizer integration.
 *
 * @since  1.0.0
 * @access public
 */
final class VW_Job_Board_Customize {

	/**
	 * Returns the instance.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return object
	 */
	public static function get_instance() {

		static $instance = null;

		if ( is_null( $instance ) ) {
			$instance = new self;
			$instance->setup_actions();
		}

		return $instance;
	}

	/**
	 * Constructor method.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function __construct() {}

	/**
	 * Sets up initial actions.
	 *
	 * @since  1.0.0
	 * @access private
	 * @return void
	 */
	private function setup_actions() {

		// Register panels, sections, settings, controls, and partials.
		add_action( 'customize_register', array( $this, 'sections' ) );

		// Register scripts and styles for the controls.
		add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_control_scripts' ), 0 );
	}

	/**
	 * Sets up the customizer sections.
	 *
	 * @since  1.0.0
	 * @access public
	 * @param  object  $manager
	 * @return void
	*/
	public function sections( $manager ) {

		// Load custom sections.
		load_template( trailingslashit( get_template_directory() ) . '/inc/section-pro.php' );

		// Register custom section types.
		$manager->register_section_type( 'VW_Job_Board_Customize_Section_Pro' );

		// Register sections.
		$manager->add_section( new VW_Job_Board_Customize_Section_Pro( $manager,'vw_job_board_go_pro', array(
			'priority'   => 1,
			'title'    => esc_html__( 'VW JOB BOARD PRO', 'vw-job-board' ),
			'pro_text' => esc_html__( 'UPGRADE PRO', 'vw-job-board' ),
			'pro_url'  => esc_url('https://www.vwthemes.com/products/job-portal-wordpress-theme'),
		)));

		// Register sections.
		$manager->add_section(new VW_Job_Board_Customize_Section_Pro($manager,'vw_job_board_get_started_link',array(
			'priority'   => 1,
			'title'    => esc_html__( 'DOCUMENTATION', 'vw-job-board' ),
			'pro_text' => esc_html__( 'DOCS', 'vw-job-board' ),
			'pro_url'  => esc_url('https://preview.vwthemesdemo.com/docs/free-vw-job-board/'),
		)));
	}

	/**
	 * Loads theme customizer CSS.
	 *
	 * @since  1.0.0
	 * @access public
	 * @return void
	 */
	public function enqueue_control_scripts() {

		wp_enqueue_script( 'vw-job-board-customize-controls', trailingslashit( get_template_directory_uri() ) . '/assets/js/customize-controls.js', array( 'customize-controls' ) );

		wp_enqueue_style( 'vw-job-board-customize-controls', trailingslashit( get_template_directory_uri() ) . '/assets/css/customize-controls.css' );
	}
}

// Doing this customizer thang!
VW_Job_Board_Customize::get_instance();